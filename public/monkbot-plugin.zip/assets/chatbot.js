/**
 * MonkBot Chatbot — Pure Vanilla JS
 * No build step, no frameworks. Communicates with the WP REST API.
 */
(function () {
    'use strict';

    // ── State ──────────────────────────────────────────────────────────────
    let messages = [
        { role: 'system', content: 'You are MonkBot, a helpful AI assistant with full access to this WordPress site. Help the user manage their site efficiently and accurately.' }
    ];
    let isLoading = false;
    let mediaRecognition = null;
    let isRecording = false;

    // ── DOM refs ───────────────────────────────────────────────────────────
    const messageList = document.getElementById('monkbot-messages');
    const inputField = document.getElementById('monkbot-input');
    const sendBtn = document.getElementById('monkbot-send');
    const micBtn = document.getElementById('monkbot-mic');
    const modelSelect = document.getElementById('monkbot-model');

    if (!messageList || !inputField || !sendBtn) return; // Not on our page

    // ── Rendering ──────────────────────────────────────────────────────────
    function renderMessage(role, text) {
        const div = document.createElement('div');
        div.className = 'monkbot-message ' + role;

        // Basic markdown: bold, code blocks, inline code, line breaks
        let html = escapeHtml(text)
            .replace(/```([\s\S]*?)```/g, '<pre><code>$1</code></pre>')
            .replace(/`([^`]+)`/g, '<code>$1</code>')
            .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
            .replace(/\n/g, '<br>');

        div.innerHTML = html;
        messageList.appendChild(div);
        messageList.scrollTop = messageList.scrollHeight;
        return div;
    }

    function renderTyping() {
        const div = document.createElement('div');
        div.className = 'monkbot-message assistant monkbot-typing';
        div.innerHTML = '<span></span><span></span><span></span>';
        messageList.appendChild(div);
        messageList.scrollTop = messageList.scrollHeight;
        return div;
    }

    function escapeHtml(text) {
        return text
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    function setLoading(state) {
        isLoading = state;
        sendBtn.disabled = state;
        inputField.disabled = state;
    }

    // ── API Call ───────────────────────────────────────────────────────────
    async function sendMessage() {
        const text = inputField.value.trim();
        if (!text || isLoading) return;

        // Add user message to state and UI
        messages.push({ role: 'user', content: text });
        renderMessage('user', text);
        inputField.value = '';
        setLoading(true);

        const typingIndicator = renderTyping();

        try {

            const response = await fetch(monkbotParams.restUrl + 'monkbot/v1/chat', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-WP-Nonce': monkbotParams.nonce,
                },
                body: JSON.stringify({ messages }),
            });

            const data = await response.json();
            typingIndicator.remove();

            if (data.status === 'success') {
                messages.push({ role: 'assistant', content: data.reply });
                renderMessage('assistant', data.reply);
            } else {
                renderMessage('assistant', '⚠️ Error: ' + (data.reply || data.message || 'Unknown error.'));
            }
        } catch (err) {
            typingIndicator.remove();
            renderMessage('assistant', '⚠️ Network error. Please check your connection.');
        }

        setLoading(false);
        inputField.focus();
    }

    // ── Event Listeners ────────────────────────────────────────────────────
    sendBtn.addEventListener('click', sendMessage);

    inputField.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });

    // ── Voice Input ────────────────────────────────────────────────────────
    if (micBtn && ('SpeechRecognition' in window || 'webkitSpeechRecognition' in window)) {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        mediaRecognition = new SpeechRecognition();
        mediaRecognition.continuous = false;
        mediaRecognition.interimResults = false;
        mediaRecognition.lang = 'en-US';

        mediaRecognition.onresult = function (event) {
            const transcript = event.results[0][0].transcript;
            inputField.value = transcript;
        };

        mediaRecognition.onend = function () {
            isRecording = false;
            micBtn.classList.remove('recording');
            micBtn.title = 'Start voice input';
        };

        micBtn.addEventListener('click', function () {
            if (isRecording) {
                mediaRecognition.stop();
            } else {
                mediaRecognition.start();
                isRecording = true;
                micBtn.classList.add('recording');
                micBtn.title = 'Stop recording';
            }
        });
    } else if (micBtn) {
        micBtn.style.display = 'none'; // Hide if not supported
    }

    // ── Welcome message ────────────────────────────────────────────────────
    renderMessage('assistant', '👋 Hello! I\'m MonkBot. I can help you manage this WordPress site. Try asking me to list recent posts, check for plugin updates, or manage WooCommerce orders!');

})();

=== MonkBot — MCP Server Bot ===
Contributors: prakharb88
Tags: ai, chatbot, mcp, openai, telegram
Requires at least: 6.9
Tested up to: 6.9
Stable tag: 1.1.0
Requires PHP: 7.4
License: GPL-2.0+
License URI: http://www.gnu.org/licenses/gpl-2.0.txt

The first WordPress MCP Server chatbot plugin — control your entire site through natural language.

== Description ==

**MonkBot is the first WordPress plugin to implement a full MCP (Model Context Protocol) server for WordPress.** Built on top of the WordPress 6.9 Abilities API (`wp_register_ability`), MonkBot registers your entire site's capabilities as structured, machine-readable AI tools — and then lets you interact with them through natural language.

Whether you're managing posts, moderating comments, updating WooCommerce orders, checking for plugin updates, or administering users — MonkBot handles it all through a sleek dashboard chatbot or directly via Telegram.

**No Node.js. No build steps. Pure PHP.**

= What makes MonkBot different? =

Most AI chatbots for WordPress are wrappers that only answer questions. MonkBot is different: it's an **MCP Server** — a bridge between an AI model and your WordPress site's live data and actions. It follows the same Model Context Protocol architecture used by tools like Claude and ChatGPT to interact with external systems.

= Key Features =

* ✅ **WordPress 6.9 Abilities API** — Registers tools using the official `wp_register_ability()` function, making them discoverable via `/wp-json/wp-abilities/v1/monkbot`
* 💬 **Dashboard Chatbot** — A beautiful, responsive chat interface built directly into the WordPress admin. Pure PHP + Vanilla JS, no React, no build step.
* 📱 **Telegram Integration** — Connect a Telegram bot and control your site from your phone
* 🧠 **OpenAI Powered** — Uses GPT-4o, GPT-4o Mini, or GPT-3.5 Turbo
* 🔧 **14+ Built-in Tools** — Posts, users, comments, system updates, and WooCommerce out of the box
* 🔌 **Extensible** — Any plugin that adopts `wp_register_ability()` automatically extends MonkBot's capabilities
* 🌐 **MCP-Compatible** — Works with the WordPress MCP Adapter to connect to external AI agents like Claude

= Built-in Capabilities =

**Site Management:** Get site info, inspect installed plugins

**Posts & Pages:** List, create, update, and delete posts of any type

**Users:** List, create, and delete WordPress users

**Comments:** View, approve, trash, spam, or delete comments

**System:** Check for plugin/theme updates, deactivate plugins

**WooCommerce (if active):** List and search products, update prices, manage orders and statuses, see top products and sales regions

= Technical Architecture =

MonkBot introduces a layered MCP architecture for WordPress:

1. **Tool Modules** (`includes/tools/*.php`) — Pure PHP execution logic for each capability
2. **Abilities Registry** (`includes/abilities.php`) — Registers all tools using `wp_register_ability()` with input/output schemas, permission callbacks, and REST exposure
3. **OpenAI Bridge** (`includes/ai-tools.php`) — Reads the WP Ability Registry at runtime and auto-generates OpenAI function-calling definitions. Zero duplication.
4. **Chat API** (`includes/api.php`) — WP REST API endpoint that handles the conversation loop, tool execution, and OpenAI multi-turn calls
5. **Telegram Webhook** (`includes/telegram.php`) — Receives Telegram messages and routes them through the same AI pipeline

== Installation ==

1. Upload the `monkbot` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Go to **MonkBot → Settings** and enter your OpenAI API Key.
4. (Optional) Enter your Telegram Bot Token and Chat ID to enable the Telegram integration.
5. After saving your Telegram token, click **"Click here to register webhook with Telegram"** to activate the Telegram integration.

== Sample Commands & Workflows ==

MonkBot understands natural language and can execute multi-step workflows autonomously. Try these powerful commands:

= Advanced Content Management =
* "Draft a new blog post titled 'Top 10 AI Tools for 2026', write a 500-word introduction about the rise of agentic web, and publish it immediately."
* "Can you find my draft post about 'Summer Sale' and update the content to say the sale ends on Friday, then change its status to published?"
= Advanced Content Management =
* "Draft a new blog post titled 'Top 10 AI Tools for 2026', write a 500-word introduction about the rise of agentic web, and publish it immediately."
* "Can you find my draft post about 'Summer Sale' and update the content to say the sale ends on Friday, then change its status to published?"
* "List all pages on my site, find the 'Contact Us' page, and tell me what the current content says. Then update it to include my new email address: hello@example.com."
* "Please duplicate the 'About Us' page and name the new draft 'About Us - 2026 Revision'."

= User & Community Moderation =
* "Find all pending comments. Read them and if any look like spam promoting crypto, mark them as spam. Approve the rest."
* "List all my subscribers. Create a new user account for 'jane.doe@example.com' with the role of Author and tell me their ID."
* "Are there any users who haven't logged in recently? Wait, just list all authors and editors."

= WooCommerce Store Operations =
* "What were my top 5 selling products over the last week? Give me their names, quantities sold, and total revenue."
* "Find order #1052. Tell me what they bought, and then update the order status to 'completed' and add a note saying 'Shipped via FedEx'."
* "Can you search for any products that have 'T-Shirt' in the title and reduce their regular price by 10%?"
* "Get me a report on sales by region for the last 30 days. Which country had the most orders?"

= System =
* "Do I have any plugins that need an update right now? If so, tell me which ones and update them for me."
* "Can you check the current installed WordPress version and see if an update is available?"
* "Deactivate the Hello Dolly plugin and clear any cache if possible."
* "List all currently active theme and plugins on the site."
* "Are there any inactive plugins taking up space? List them so I can review."

= Database Introspection =
* "List all the database tables in my installation and tell me how many there are in total."
* "Show me the exact schema columns and their data types for the `wp_options` table."
* "Run a query to find the 5 largest autoloader options in my `wp_options` table to help me debug performance."
* "Can you search the `wp_postmeta` table for any rows where the `meta_key` contains the word 'cache'?"
* "Count how many users are in the `wp_users` table directly."
* "Inspect the schema of the `wp_woocommerce_order_items` table and explain how an order is structured."

= WordPress Hooks =
* "List all registered WordPress hooks whose names contain 'woocommerce' so I know what I can filter."
* "I want to hook into the post saving process. Search for action hooks containing 'save_post'."
* "Can you find what callbacks are currently registered to the `init` hook?"
* "Which functions are hooked into `wp_enqueue_scripts` and at what priority levels?"
* "Search for any hooks related to user authentication, maybe something containing 'login'."
* "Tell me how many callbacks are attached to the `template_redirect` action."

= Advanced Custom Fields (ACF) =
* "List all the ACF Field Groups registered on my website."
* "Find the ACF field group called 'Product Specifications' and list all the fields inside it."
* "Explain all the Advanced Custom Fields attached to Post ID 45."
* "Get me the value of the ACF field named 'hero_headline' on page ID 12."
* "Which fields are available in the 'group_author_bio' field group?"
* "Retrieve the values for 'event_date' and 'event_location' ACF fields on the latest published event post."

= WP Shell / Code Execution =
* "Execute a PHP script to return `get_bloginfo('url')` so I can confirm the absolute base URL."
* "Run `wp_get_current_user()` via the shell and verify which user ID is executing the chatbot."
* "Can you run a quick script to check if `WP_DEBUG` is defined and true?"
* "Evaluate a short PHP snippet to get the total number of approved comments using `get_comments()`."
* "Write and execute a script that clears all WordPress transients using `delete_transient()`."
* "Use the WP Shell to fetch the latest post IDs and return them as a JSON array string."

= Pro Tips =
* **Chaining:** MonkBot can execute up to 5 tool tools in a single response. You can give complex instructions like: "List pending comments, delete them, then check for plugin updates."
* **Context-Aware:** MonkBot remembers the conversation. You can say "List my recent products" and then "Put the first one on sale for $10."

== 🚀 Enterprise & Custom Integrations ==

This plugin is the **Free Version** of MonkBot. Because it is built on the universal Model Context Protocol (MCP), it can be thoroughly customized for your exact industry-specific requirements.

**Need a custom AI Agent? We can build it:**
* **Local LLMs:** Run the agent on your own absolute-privacy local LLMs (Llama 3, Mistral) instead of OpenAI.
* **Team Chat Integration:** We can connect this directly to your Slack workspace or Microsoft Teams so your whole company can query the site. (Telegram is already included in the Free version!)
* **CRM Syncing:** Integrate MonkBot directly with Salesforce or HubSpot to automatically manage WooCommerce leads.
* **Customer Support:** Connect your site data directly to WhatsApp to automatically answer customer queries.

Contact the developer to discuss custom integrations for your business.

== External Services ==

This plugin connects to two third-party services. Data is only transmitted when you actively use the relevant features. No data is sent on plugin activation or in the background.

= 1. OpenAI API =

**What data is sent:** When a message is submitted via the MonkBot dashboard chatbot or received via Telegram, the following data is transmitted to OpenAI's servers:

* The full conversation message history (user messages and assistant replies)
* Relevant WordPress site data retrieved by AI tools — this may include post titles, post content, usernames, comment text, plugin names, WooCommerce order details, product names, prices, and database query results, depending on what information the AI requests to answer your query
* The name and version of the AI model selected in settings

**When it is sent:** Only when a chat message is submitted (dashboard chatbot) or a Telegram message is received by the bot.

**Who receives it:** OpenAI, L.L.C., 3180 18th St, San Francisco, CA 94110, USA.

* [OpenAI Privacy Policy](https://openai.com/privacy)
* [OpenAI Terms of Use](https://openai.com/terms)
* [OpenAI API Data Usage Policies](https://openai.com/policies/api-data-usage-policies)

= 2. Telegram Bot API =

**What data is sent:** This service is entirely optional and only activates if you enter a Telegram Bot Token in MonkBot Settings. When enabled:

* Incoming Telegram messages (text content and the sender's Telegram chat ID) are received by your WordPress site via a registered webhook
* Reply text generated by the OpenAI API is sent back to Telegram to deliver the response to the user

**When it is sent:** Only when a Telegram user sends a message to your configured bot.

**Who receives it:** Telegram Messenger Inc., Tortola, British Virgin Islands.

* [Telegram Privacy Policy](https://telegram.org/privacy)
* [Telegram Terms of Service](https://telegram.org/tos)
* [Telegram Bot API Documentation](https://core.telegram.org/bots/api)

== Frequently Asked Questions ==

= Do I need Node.js or npm? =
No. MonkBot is 100% PHP. No build tools, no Node.js, no npm required.

= Is this safe to use? =
MonkBot only allows logged-in WordPress admins to use the chatbot. All tool executions are gated by WordPress capability checks (`manage_options`). That said — because it has genuine site management powers, you should only grant access to trusted administrators.

= Can I add my own tools? =
Yes! Register a new `wp_register_ability()` in your own plugin and MonkBot will automatically discover and include it. See the WordPress 6.9 Abilities API documentation for details.

= Does this work with external AI clients like Claude or ChatGPT? =
With the WordPress MCP Adapter plugin installed, MonkBot's registered abilities become accessible to any MCP-compatible AI client.

= What happens if I'm on WordPress < 6.9? =
MonkBot includes a full legacy fallback using its own static tool definitions. All chatbot and Telegram functionality works — only the WP Abilities API registration and REST discoverability require WP 6.9.

== Screenshots ==

1. The MonkBot chat widget inside the WordPress dashboard.
2. The settings page — configure OpenAI API key, model, and Telegram webhook.

== Changelog ==

= 1.0.0 =
* Initial public release
* WordPress 6.9 Abilities API integration with `wp_register_ability()`
* 14 built-in abilities across Posts, Users, Comments, System, and WooCommerce
* Dashboard chatbot — pure PHP + Vanilla JS, no build step
* Telegram Bot integration with webhook support
* OpenAI bridge: auto-generates function-calling definitions from WP Ability Registry
* REST API discoverability at `/wp-json/wp-abilities/v1/monkbot`

== Upgrade Notice ==

= 1.0.0 =
Initial release.

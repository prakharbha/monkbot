<?php
if (!defined('ABSPATH')) {
    exit;
}

function monkbot_get_users_tools()
{
    return array(
        array(
            'type' => 'function',
            'function' => array(
                'name' => 'list_users',
                'description' => 'Retrieve a list of users on the site.',
                'parameters' => array(
                    'type' => 'object',
                    'properties' => array(
                        'role' => array('type' => 'string', 'description' => 'Filter by role (e.g., administrator, subscriber)'),
                        'number' => array('type' => 'integer', 'description' => 'Number of users to return. Default: 10'),
                        'offset' => array('type' => 'integer', 'description' => 'Offset for pagination. Default: 0'),
                    )
                )
            )
        ),
        array(
            'type' => 'function',
            'function' => array(
                'name' => 'create_user',
                'description' => 'Create a new user.',
                'parameters' => array(
                    'type' => 'object',
                    'required' => array('username', 'email', 'password'),
                    'properties' => array(
                        'username' => array('type' => 'string', 'description' => 'Username'),
                        'email' => array('type' => 'string', 'description' => 'Email address'),
                        'password' => array('type' => 'string', 'description' => 'Password'),
                        'role' => array('type' => 'string', 'description' => 'User role (administrator, editor, subscriber). Default: subscriber'),
                    )
                )
            )
        ),
        array(
            'type' => 'function',
            'function' => array(
                'name' => 'delete_user',
                'description' => 'Delete a user by ID.',
                'parameters' => array(
                    'type' => 'object',
                    'required' => array('user_id'),
                    'properties' => array(
                        'user_id' => array('type' => 'integer', 'description' => 'User ID to delete.'),
                        'reassign_to' => array('type' => 'integer', 'description' => 'User ID to reassign posts to. Leave empty to delete posts.')
                    )
                )
            )
        )
    );
}

function monkbot_execute_users_tool($tool_name, $arguments)
{
    if (!function_exists('wp_insert_user')) {
        require_once ABSPATH . 'wp-admin/includes/user.php';
    }

    switch ($tool_name) {
        case 'list_users':
            $args = array(
                'number' => $arguments['number'] ?? 10,
                'offset' => $arguments['offset'] ?? 0,
            );
            if (!empty($arguments['role'])) {
                $args['role'] = $arguments['role'];
            }
            $user_query = new WP_User_Query($args);
            $users_data = array();

            foreach ($user_query->get_results() as $user) {
                $users_data[] = array(
                    'id' => $user->ID,
                    'username' => $user->user_login,
                    'email' => $user->user_email,
                    'roles' => $user->roles,
                    'registered' => $user->user_registered
                );
            }
            return json_encode(array('total' => $user_query->get_total(), 'users' => $users_data));

        case 'create_user':
            $requested_role = sanitize_key($arguments['role'] ?? 'subscriber');

            // Security setting check: if creating admin accounts is disabled, force subscriber
            $allow_admin = (bool) get_option('monkbot_allow_create_admin', 1);
            if (!$allow_admin && $requested_role === 'administrator') {
                return json_encode(array(
                    'error' => 'Creating administrator accounts is disabled in MonkBot Security Settings. The AI can create users with roles up to editor.'
                ));
            }

            $user_id = wp_insert_user(array(
                'user_login' => sanitize_user($arguments['username']),
                'user_pass' => $arguments['password'],
                'user_email' => sanitize_email($arguments['email']),
                'role' => $requested_role,
            ));

            if (is_wp_error($user_id)) {
                return json_encode(array('error' => $user_id->get_error_message()));
            }
            return json_encode(array('message' => 'Successfully created user.', 'user_id' => $user_id));

        case 'delete_user':
            $user_id = intval($arguments['user_id']);
            $reassign = isset($arguments['reassign_to']) ? intval($arguments['reassign_to']) : null;

            if ($user_id === get_current_user_id()) {
                return json_encode(array('error' => 'You cannot delete yourself.'));
            }

            $result = wp_delete_user($user_id, $reassign);
            if ($result) {
                return json_encode(array('message' => "Successfully deleted user ID $user_id."));
            } else {
                return json_encode(array('error' => "Failed to delete user ID $user_id."));
            }
    }
    return false;
}

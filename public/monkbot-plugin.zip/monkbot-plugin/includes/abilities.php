<?php
/**
 * MonkBot Abilities Registry — WordPress 6.9 Abilities API
 *
 * Registers all MonkBot tools using wp_register_ability() so that they are
 * discoverable by the WordPress MCP server, the REST API, and external AI clients.
 *
 * The existing execute functions in includes/tools/*.php are reused directly
 * as the execute_callback for each ability — no duplication.
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Registers the MonkBot category for the Abilities API.
 * Hooked into 'wp_abilities_api_categories_init'.
 */
function monkbot_register_ability_categories()
{
    if (!function_exists('wp_register_ability_category')) {
        return;
    }

    wp_register_ability_category('monkbot', array(
        'label' => __('MonkBot Site Management', 'monkbot'),
        'description' => __('AI-powered tools for managing WordPress content, users, and system settings.', 'monkbot'),
    ));
}
add_action('wp_abilities_api_categories_init', 'monkbot_register_ability_categories');

/**
 * Registers all MonkBot abilities for the Abilities API.
 * Hooked into 'wp_abilities_api_init'.
 */
function monkbot_register_all_abilities()
{
    // Only register if the Abilities API is available (WP 6.9+)
    if (!function_exists('wp_register_ability')) {
        return;
    }

    // -----------------------------------------------------------
    // 2. SITE INFO
    // -----------------------------------------------------------
    wp_register_ability('monkbot/get-site-info', array(
        'label' => __('Get Site Information', 'monkbot'),
        'description' => __('Returns the site name and tagline.', 'monkbot'),
        'category' => 'monkbot',
        'input_schema' => array('type' => 'object', 'properties' => new stdClass()),
        'output_schema' => array('type' => 'string', 'description' => 'JSON string with site_title and site_description.'),
        'execute_callback' => 'monkbot_ability_get_site_info',
        'permission_callback' => 'monkbot_ability_require_admin',
        'meta' => array('show_in_rest' => true),
    ));

    // -----------------------------------------------------------
    // 3. POSTS
    // -----------------------------------------------------------
    wp_register_ability('monkbot/list-posts', array(
        'label' => __('List Posts', 'monkbot'),
        'description' => __('Retrieve a list of posts, pages, or custom post types.', 'monkbot'),
        'category' => 'monkbot',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'post_type' => array('type' => 'string', 'description' => 'Post type (e.g., post, page). Default: any'),
                'number' => array('type' => 'integer', 'description' => 'Number of posts. Default: 10'),
                'offset' => array('type' => 'integer', 'description' => 'Offset for pagination. Default: 0'),
            ),
        ),
        'output_schema' => array('type' => 'string', 'description' => 'JSON with total and posts array.'),
        'execute_callback' => function ($input) {
            return monkbot_execute_posts_tool('list_posts', (array) $input);
        },
        'permission_callback' => 'monkbot_ability_require_admin',
        'meta' => array('show_in_rest' => true),
    ));

    wp_register_ability('monkbot/create-or-update-post', array(
        'label' => __('Create or Update Post', 'monkbot'),
        'description' => __('Create a new post or update an existing one if ID is provided.', 'monkbot'),
        'category' => 'monkbot',
        'input_schema' => array(
            'type' => 'object',
            'required' => array('title', 'content'),
            'properties' => array(
                'post_id' => array('type' => 'integer', 'description' => 'ID of post to update (leave empty to create).'),
                'title' => array('type' => 'string', 'description' => 'Post title.'),
                'content' => array('type' => 'string', 'description' => 'Post content.'),
                'post_type' => array('type' => 'string', 'description' => 'Post type. Default: post'),
                'status' => array('type' => 'string', 'description' => 'Status (publish, draft). Default: draft'),
            ),
        ),
        'output_schema' => array('type' => 'string', 'description' => 'JSON with result message and post_id.'),
        'execute_callback' => function ($input) {
            return monkbot_execute_posts_tool('create_or_update_post', (array) $input);
        },
        'permission_callback' => 'monkbot_ability_require_admin',
        'meta' => array('show_in_rest' => true),
    ));

    wp_register_ability('monkbot/delete-post', array(
        'label' => __('Delete Post', 'monkbot'),
        'description' => __('Delete a post by ID.', 'monkbot'),
        'category' => 'monkbot',
        'input_schema' => array(
            'type' => 'object',
            'required' => array('post_id'),
            'properties' => array(
                'post_id' => array('type' => 'integer', 'description' => 'The post ID to delete.'),
                'force_delete' => array('type' => 'boolean', 'description' => 'Bypass trash. Default: false'),
            ),
        ),
        'output_schema' => array('type' => 'string', 'description' => 'JSON result message.'),
        'execute_callback' => function ($input) {
            return monkbot_execute_posts_tool('delete_post', (array) $input);
        },
        'permission_callback' => 'monkbot_ability_require_admin',
        'meta' => array('show_in_rest' => true),
    ));

    // -----------------------------------------------------------
    // 4. USERS
    // -----------------------------------------------------------
    wp_register_ability('monkbot/list-users', array(
        'label' => __('List Users', 'monkbot'),
        'description' => __('Retrieve a list of users on the site.', 'monkbot'),
        'category' => 'monkbot',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'role' => array('type' => 'string', 'description' => 'Filter by role (e.g., administrator).'),
                'number' => array('type' => 'integer', 'description' => 'Number of users. Default: 10'),
                'offset' => array('type' => 'integer', 'description' => 'Pagination offset. Default: 0'),
            ),
        ),
        'output_schema' => array('type' => 'string', 'description' => 'JSON with total and users array.'),
        'execute_callback' => function ($input) {
            return monkbot_execute_users_tool('list_users', (array) $input);
        },
        'permission_callback' => 'monkbot_ability_require_admin',
        'meta' => array('show_in_rest' => true),
    ));

    wp_register_ability('monkbot/create-user', array(
        'label' => __('Create User', 'monkbot'),
        'description' => __('Create a new WordPress user.', 'monkbot'),
        'category' => 'monkbot',
        'input_schema' => array(
            'type' => 'object',
            'required' => array('username', 'email', 'password'),
            'properties' => array(
                'username' => array('type' => 'string', 'description' => 'Username.'),
                'email' => array('type' => 'string', 'description' => 'Email address.'),
                'password' => array('type' => 'string', 'description' => 'Password.'),
                'role' => array('type' => 'string', 'description' => 'User role. Default: subscriber'),
            ),
        ),
        'output_schema' => array('type' => 'string', 'description' => 'JSON result message.'),
        'execute_callback' => function ($input) {
            return monkbot_execute_users_tool('create_user', (array) $input);
        },
        'permission_callback' => 'monkbot_ability_require_admin',
        'meta' => array('show_in_rest' => true),
    ));

    wp_register_ability('monkbot/delete-user', array(
        'label' => __('Delete User', 'monkbot'),
        'description' => __('Delete a WordPress user by ID.', 'monkbot'),
        'category' => 'monkbot',
        'input_schema' => array(
            'type' => 'object',
            'required' => array('user_id'),
            'properties' => array(
                'user_id' => array('type' => 'integer', 'description' => 'User ID to delete.'),
                'reassign_to' => array('type' => 'integer', 'description' => 'User ID to reassign their posts to.'),
            ),
        ),
        'output_schema' => array('type' => 'string', 'description' => 'JSON result message.'),
        'execute_callback' => function ($input) {
            return monkbot_execute_users_tool('delete_user', (array) $input);
        },
        'permission_callback' => 'monkbot_ability_require_admin',
        'meta' => array('show_in_rest' => true),
    ));

    // -----------------------------------------------------------
    // 5. COMMENTS
    // -----------------------------------------------------------
    wp_register_ability('monkbot/list-comments', array(
        'label' => __('List Comments', 'monkbot'),
        'description' => __('Retrieve a list of comments on the site.', 'monkbot'),
        'category' => 'monkbot',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'status' => array('type' => 'string', 'description' => 'Status filter (approve, hold, spam, trash). Default: all'),
                'number' => array('type' => 'integer', 'description' => 'Number of comments. Default: 10'),
                'offset' => array('type' => 'integer', 'description' => 'Pagination offset. Default: 0'),
            ),
        ),
        'output_schema' => array('type' => 'string', 'description' => 'JSON with comments array.'),
        'execute_callback' => function ($input) {
            return monkbot_execute_comments_tool('list_comments', (array) $input);
        },
        'permission_callback' => 'monkbot_ability_require_admin',
        'meta' => array('show_in_rest' => true),
    ));

    wp_register_ability('monkbot/update-comment-status', array(
        'label' => __('Update Comment Status', 'monkbot'),
        'description' => __('Update the status of a specific comment.', 'monkbot'),
        'category' => 'monkbot',
        'input_schema' => array(
            'type' => 'object',
            'required' => array('comment_id', 'status'),
            'properties' => array(
                'comment_id' => array('type' => 'integer', 'description' => 'The comment ID.'),
                'status' => array('type' => 'string', 'description' => 'New status: approve, hold, spam, or trash.'),
            ),
        ),
        'output_schema' => array('type' => 'string', 'description' => 'JSON result message.'),
        'execute_callback' => function ($input) {
            return monkbot_execute_comments_tool('update_comment_status', (array) $input);
        },
        'permission_callback' => 'monkbot_ability_require_admin',
        'meta' => array('show_in_rest' => true),
    ));

    wp_register_ability('monkbot/delete-comment', array(
        'label' => __('Delete Comment', 'monkbot'),
        'description' => __('Permanently delete a comment.', 'monkbot'),
        'category' => 'monkbot',
        'input_schema' => array(
            'type' => 'object',
            'required' => array('comment_id'),
            'properties' => array(
                'comment_id' => array('type' => 'integer', 'description' => 'The comment ID to delete.'),
                'force_delete' => array('type' => 'boolean', 'description' => 'Bypass trash. Default: false'),
            ),
        ),
        'output_schema' => array('type' => 'string', 'description' => 'JSON result message.'),
        'execute_callback' => function ($input) {
            return monkbot_execute_comments_tool('delete_comment', (array) $input);
        },
        'permission_callback' => 'monkbot_ability_require_admin',
        'meta' => array('show_in_rest' => true),
    ));

    // -----------------------------------------------------------
    // 6. SYSTEM
    // -----------------------------------------------------------
    wp_register_ability('monkbot/list-updates-required', array(
        'label' => __('List Available Updates', 'monkbot'),
        'description' => __('Check if any installed plugins or themes have updates available.', 'monkbot'),
        'category' => 'monkbot',
        'input_schema' => array('type' => 'object', 'properties' => new stdClass()),
        'output_schema' => array('type' => 'string', 'description' => 'JSON with plugins needing update.'),
        'execute_callback' => function ($input) {
            return monkbot_execute_system_tool('list_updates_required', array());
        },
        'permission_callback' => 'monkbot_ability_require_admin',
        'meta' => array('show_in_rest' => true),
    ));

    wp_register_ability('monkbot/deactivate-plugin', array(
        'label' => __('Deactivate Plugin', 'monkbot'),
        'description' => __('Deactivate a specific installed plugin by its file path.', 'monkbot'),
        'category' => 'monkbot',
        'input_schema' => array(
            'type' => 'object',
            'required' => array('plugin_file'),
            'properties' => array(
                'plugin_file' => array('type' => 'string', 'description' => 'Plugin file path relative to plugins dir (e.g., akismet/akismet.php).'),
            ),
        ),
        'output_schema' => array('type' => 'string', 'description' => 'JSON result message.'),
        'execute_callback' => function ($input) {
            return monkbot_execute_system_tool('deactivate_plugin', (array) $input);
        },
        'permission_callback' => 'monkbot_ability_require_admin',
        'meta' => array('show_in_rest' => true),
    ));

    // -----------------------------------------------------------
    // 7. WOOCOMMERCE (conditional)
    // -----------------------------------------------------------
    if (class_exists('WooCommerce')) {
        wp_register_ability('monkbot/list-wc-products', array(
            'label' => __('List WooCommerce Products', 'monkbot'),
            'description' => __('Retrieve a list of WooCommerce products.', 'monkbot'),
            'category' => 'monkbot',
            'input_schema' => array(
                'type' => 'object',
                'properties' => array(
                    'status' => array('type' => 'string', 'description' => 'Product status (publish, draft). Default: publish'),
                    'limit' => array('type' => 'integer', 'description' => 'Number to return. Default: 10'),
                    'offset' => array('type' => 'integer', 'description' => 'Pagination offset. Default: 0'),
                ),
            ),
            'output_schema' => array('type' => 'string', 'description' => 'JSON with products array.'),
            'execute_callback' => function ($input) {
                return monkbot_execute_woocommerce_tool('list_wc_products', (array) $input);
            },
            'permission_callback' => 'monkbot_ability_require_admin',
            'meta' => array('show_in_rest' => true),
        ));

        wp_register_ability('monkbot/update-wc-product-price', array(
            'label' => __('Update Product Price', 'monkbot'),
            'description' => __('Update the regular or sale price of a WooCommerce product.', 'monkbot'),
            'category' => 'monkbot',
            'input_schema' => array(
                'type' => 'object',
                'required' => array('product_id'),
                'properties' => array(
                    'product_id' => array('type' => 'integer', 'description' => 'The product ID.'),
                    'regular_price' => array('type' => 'string', 'description' => 'New regular price.'),
                    'sale_price' => array('type' => 'string', 'description' => 'New sale price. Set to "clear" to remove.'),
                ),
            ),
            'output_schema' => array('type' => 'string', 'description' => 'JSON result message.'),
            'execute_callback' => function ($input) {
                return monkbot_execute_woocommerce_tool('update_wc_product_price', (array) $input);
            },
            'permission_callback' => 'monkbot_ability_require_admin',
            'meta' => array('show_in_rest' => true),
        ));

        wp_register_ability('monkbot/list-wc-orders', array(
            'label' => __('List WooCommerce Orders', 'monkbot'),
            'description' => __('Retrieve a basic list of WooCommerce orders (does NOT include customer country/region data — use wc-revenue-by-region for that).', 'monkbot'),
            'category' => 'monkbot',
            'input_schema' => array(
                'type' => 'object',
                'properties' => array(
                    'status' => array('type' => 'string', 'description' => 'Order status (pending, processing, completed, any). Default: any'),
                    'limit' => array('type' => 'integer', 'description' => 'Number of orders. Default: 10'),
                ),
            ),
            'output_schema' => array('type' => 'string', 'description' => 'JSON with orders array.'),
            'execute_callback' => function ($input) {
                return monkbot_execute_woocommerce_tool('list_wc_orders', (array) $input);
            },
            'permission_callback' => 'monkbot_ability_require_admin',
            'meta' => array('show_in_rest' => true),
        ));

        wp_register_ability('monkbot/update-wc-order-status', array(
            'label' => __('Update WooCommerce Order Status', 'monkbot'),
            'description' => __('Update the status of a WooCommerce order.', 'monkbot'),
            'category' => 'monkbot',
            'input_schema' => array(
                'type' => 'object',
                'required' => array('order_id', 'status'),
                'properties' => array(
                    'order_id' => array('type' => 'integer', 'description' => 'The order ID.'),
                    'status' => array('type' => 'string', 'description' => 'New status (pending, processing, completed, cancelled).'),
                ),
            ),
            'output_schema' => array('type' => 'string', 'description' => 'JSON result message.'),
            'execute_callback' => function ($input) {
                return monkbot_execute_woocommerce_tool('update_wc_order_status', (array) $input);
            },
            'permission_callback' => 'monkbot_ability_require_admin',
            'meta' => array('show_in_rest' => true),
        ));

        // ── WooCommerce Analytics ─────────────────────────────────────
        wp_register_ability('monkbot/wc-revenue-summary', array(
            'label' => __('WooCommerce Revenue Summary', 'monkbot'),
            'description' => __('Get total orders, total revenue, and average order value for a given period.', 'monkbot'),
            'category' => 'monkbot',
            'input_schema' => array(
                'type' => 'object',
                'properties' => array(
                    'days' => array('type' => 'integer', 'description' => 'Number of days to look back. Default: 30, max: 365.'),
                ),
            ),
            'output_schema' => array('type' => 'string', 'description' => 'JSON with total_orders, total_revenue, average_order, currency.'),
            'execute_callback' => function ($input) {
                return monkbot_execute_woocommerce_tool('wc_revenue_summary', (array) $input);
            },
            'permission_callback' => 'monkbot_ability_require_admin',
            'meta' => array('show_in_rest' => true),
        ));

        wp_register_ability('monkbot/wc-top-products', array(
            'label' => __('WooCommerce Top Products', 'monkbot'),
            'description' => __('List the best-selling products by revenue for a given period.', 'monkbot'),
            'category' => 'monkbot',
            'input_schema' => array(
                'type' => 'object',
                'properties' => array(
                    'days' => array('type' => 'integer', 'description' => 'Days to look back. Default: 30.'),
                    'limit' => array('type' => 'integer', 'description' => 'Number of top products to return. Default: 10.'),
                ),
            ),
            'output_schema' => array('type' => 'string', 'description' => 'JSON list of top products with qty_sold and revenue.'),
            'execute_callback' => function ($input) {
                return monkbot_execute_woocommerce_tool('wc_top_products', (array) $input);
            },
            'permission_callback' => 'monkbot_ability_require_admin',
            'meta' => array('show_in_rest' => true),
        ));

        wp_register_ability('monkbot/wc-category-breakdown', array(
            'label' => __('WooCommerce Category Breakdown', 'monkbot'),
            'description' => __('Show revenue and quantity sold broken down by WooCommerce product category.', 'monkbot'),
            'category' => 'monkbot',
            'input_schema' => array(
                'type' => 'object',
                'properties' => array(
                    'days' => array('type' => 'integer', 'description' => 'Days to look back. Default: 30.'),
                ),
            ),
            'output_schema' => array('type' => 'string', 'description' => 'JSON list of categories with revenue and qty_sold.'),
            'execute_callback' => function ($input) {
                return monkbot_execute_woocommerce_tool('wc_category_breakdown', (array) $input);
            },
            'permission_callback' => 'monkbot_ability_require_admin',
            'meta' => array('show_in_rest' => true),
        ));

        wp_register_ability('monkbot/wc-revenue-by-region', array(
            'label' => __('WooCommerce Revenue by Region', 'monkbot'),
            'description' => __('Show order counts and revenue broken down by customer billing country, state, or region. Use this to answer queries like "which country has the most sales?".', 'monkbot'),
            'category' => 'monkbot',
            'input_schema' => array(
                'type' => 'object',
                'properties' => array(
                    'days' => array('type' => 'integer', 'description' => 'Days to look back. Default: 30.'),
                ),
            ),
            'output_schema' => array('type' => 'string', 'description' => 'JSON list of regions with orders and revenue.'),
            'execute_callback' => function ($input) {
                return monkbot_execute_woocommerce_tool('wc_revenue_by_region', (array) $input);
            },
            'permission_callback' => 'monkbot_ability_require_admin',
            'meta' => array('show_in_rest' => true),
        ));

        wp_register_ability('monkbot/wc-daily-sales-trend', array(
            'label' => __('WooCommerce Daily Sales Trend', 'monkbot'),
            'description' => __('Get daily orders and revenue for the last N days, with an overall trend direction (upward/downward/flat).', 'monkbot'),
            'category' => 'monkbot',
            'input_schema' => array(
                'type' => 'object',
                'properties' => array(
                    'days' => array('type' => 'integer', 'description' => 'Number of days to include. Default: 30, max: 90.'),
                ),
            ),
            'output_schema' => array('type' => 'string', 'description' => 'JSON with trend (upward/downward/flat) and daily_data array.'),
            'execute_callback' => function ($input) {
                return monkbot_execute_woocommerce_tool('wc_daily_sales_trend', (array) $input);
            },
            'permission_callback' => 'monkbot_ability_require_admin',
            'meta' => array('show_in_rest' => true),
        ));
    }

    // -----------------------------------------------------------
    // 8. HOOKS INTROSPECTION
    // -----------------------------------------------------------
    wp_register_ability('monkbot/list-hooks', array(
        'label' => __('List WordPress Hooks', 'monkbot'),
        'description' => __('List all registered WordPress actions and filters. Optionally filter by search term.', 'monkbot'),
        'category' => 'monkbot',
        'input_schema' => array(
            'type' => 'object',
            'properties' => array(
                'search' => array('type' => 'string', 'description' => 'Filter hooks by name substring.'),
                'limit' => array('type' => 'integer', 'description' => 'Max hooks to return. Default: 50'),
            ),
        ),
        'output_schema' => array('type' => 'string', 'description' => 'JSON list of hooks with callback counts.'),
        'execute_callback' => function ($input) {
            return monkbot_execute_hooks_tool('list_hooks', (array) $input);
        },
        'permission_callback' => 'monkbot_ability_require_admin',
        'meta' => array('show_in_rest' => true),
    ));

    wp_register_ability('monkbot/get-hook-callbacks', array(
        'label' => __('Get Hook Callbacks', 'monkbot'),
        'description' => __('List all callbacks registered on a specific WordPress hook, grouped by priority.', 'monkbot'),
        'category' => 'monkbot',
        'input_schema' => array(
            'type' => 'object',
            'required' => array('hook'),
            'properties' => array(
                'hook' => array('type' => 'string', 'description' => 'The hook name (e.g., the_content, wp_head).'),
            ),
        ),
        'output_schema' => array('type' => 'string', 'description' => 'JSON map of priority => callbacks.'),
        'execute_callback' => function ($input) {
            return monkbot_execute_hooks_tool('get_hook_callbacks', (array) $input);
        },
        'permission_callback' => 'monkbot_ability_require_admin',
        'meta' => array('show_in_rest' => true),
    ));

    wp_register_ability('monkbot/search-hooks', array(
        'label' => __('Search Hooks', 'monkbot'),
        'description' => __('Search registered WordPress hooks by keyword and return matches.', 'monkbot'),
        'category' => 'monkbot',
        'input_schema' => array(
            'type' => 'object',
            'required' => array('keyword'),
            'properties' => array(
                'keyword' => array('type' => 'string', 'description' => 'Keyword to search for in hook names.'),
            ),
        ),
        'output_schema' => array('type' => 'string', 'description' => 'JSON list of matching hooks.'),
        'execute_callback' => function ($input) {
            return monkbot_execute_hooks_tool('search_hooks', (array) $input);
        },
        'permission_callback' => 'monkbot_ability_require_admin',
        'meta' => array('show_in_rest' => true),
    ));

    // -----------------------------------------------------------
    // 9. DATABASE TOOLS
    // -----------------------------------------------------------
    wp_register_ability('monkbot/database-schema', array(
        'label' => __('Database Schema', 'monkbot'),
        'description' => __('Return the full database schema: all tables and their column definitions.', 'monkbot'),
        'category' => 'monkbot',
        'input_schema' => array('type' => 'object', 'properties' => new stdClass()),
        'output_schema' => array('type' => 'string', 'description' => 'JSON map of table => columns.'),
        'execute_callback' => function ($input) {
            return monkbot_execute_database_tool('database_schema', array());
        },
        'permission_callback' => 'monkbot_ability_require_admin',
        'meta' => array('show_in_rest' => true),
    ));

    wp_register_ability('monkbot/database-query', array(
        'label' => __('Database Query (SELECT only)', 'monkbot'),
        'description' => __('Run a read-only SQL SELECT query on the WordPress database. UNION and write queries are blocked.', 'monkbot'),
        'category' => 'monkbot',
        'input_schema' => array(
            'type' => 'object',
            'required' => array('sql'),
            'properties' => array(
                'sql' => array('type' => 'string', 'description' => 'The SELECT SQL template. Use %s for strings, %d for integers, %f for floats. E.g. SELECT * FROM wp_posts WHERE post_type = %s'),
                'params' => array('type' => 'array', 'items' => array('type' => 'string'), 'description' => 'Array of values to bind to the placeholders in the SQL template.'),
                'limit' => array('type' => 'integer', 'description' => 'Max rows to return. Default: 50'),
            ),
        ),
        'output_schema' => array('type' => 'string', 'description' => 'JSON with row_count and results array.'),
        'execute_callback' => function ($input) {
            return monkbot_execute_database_tool('database_query', (array) $input);
        },
        'permission_callback' => 'monkbot_ability_require_admin',
        'meta' => array('show_in_rest' => true),
    ));

    wp_register_ability('monkbot/get-option', array(
        'label' => __('Get WordPress Option', 'monkbot'),
        'description' => __('Read any WordPress option value from the database by its option name.', 'monkbot'),
        'category' => 'monkbot',
        'input_schema' => array(
            'type' => 'object',
            'required' => array('option_name'),
            'properties' => array(
                'option_name' => array('type' => 'string', 'description' => 'The wp_options option name (e.g., blogname, siteurl).'),
            ),
        ),
        'output_schema' => array('type' => 'string', 'description' => 'JSON with found flag and value.'),
        'execute_callback' => function ($input) {
            return monkbot_execute_database_tool('get_option', (array) $input);
        },
        'permission_callback' => 'monkbot_ability_require_admin',
        'meta' => array('show_in_rest' => true),
    ));

    // Note: wp-shell ability has been intentionally removed for security.
    // The shell.php tool file has also been excluded from the plugin distribution.

    // -----------------------------------------------------------
    // 11. ACF (conditional)
    // -----------------------------------------------------------
    if (function_exists('acf_get_field_groups')) {
        wp_register_ability('monkbot/list-acf-field-groups', array(
            'label' => __('List ACF Field Groups', 'monkbot'),
            'description' => __('List all Advanced Custom Fields (ACF) field groups registered on this site.', 'monkbot'),
            'category' => 'monkbot',
            'input_schema' => array('type' => 'object', 'properties' => new stdClass()),
            'output_schema' => array('type' => 'string', 'description' => 'JSON list of field groups with keys and titles.'),
            'execute_callback' => function ($input) {
                return monkbot_execute_acf_tool('list_acf_field_groups', array());
            },
            'permission_callback' => 'monkbot_ability_require_admin',
            'meta' => array('show_in_rest' => true),
        ));

        wp_register_ability('monkbot/list-acf-fields', array(
            'label' => __('List ACF Fields in Group', 'monkbot'),
            'description' => __('List all fields within an ACF field group by its group key.', 'monkbot'),
            'category' => 'monkbot',
            'input_schema' => array(
                'type' => 'object',
                'required' => array('group_key'),
                'properties' => array(
                    'group_key' => array('type' => 'string', 'description' => 'The ACF field group key (e.g., group_abc123).'),
                ),
            ),
            'output_schema' => array('type' => 'string', 'description' => 'JSON list of fields with name, type, and label.'),
            'execute_callback' => function ($input) {
                return monkbot_execute_acf_tool('list_acf_fields', (array) $input);
            },
            'permission_callback' => 'monkbot_ability_require_admin',
            'meta' => array('show_in_rest' => true),
        ));

        wp_register_ability('monkbot/get-acf-field-value', array(
            'label' => __('Get ACF Field Value', 'monkbot'),
            'description' => __('Get the value of a specific ACF field for a given post ID.', 'monkbot'),
            'category' => 'monkbot',
            'input_schema' => array(
                'type' => 'object',
                'required' => array('post_id', 'field_name'),
                'properties' => array(
                    'post_id' => array('type' => 'integer', 'description' => 'The post ID.'),
                    'field_name' => array('type' => 'string', 'description' => 'The ACF field name (slug).'),
                ),
            ),
            'output_schema' => array('type' => 'string', 'description' => 'JSON with field name and value.'),
            'execute_callback' => function ($input) {
                return monkbot_execute_acf_tool('get_acf_field_value', (array) $input);
            },
            'permission_callback' => 'monkbot_ability_require_admin',
            'meta' => array('show_in_rest' => true),
        ));

        wp_register_ability('monkbot/get-acf-all-fields', array(
            'label' => __('Get All ACF Fields for Post', 'monkbot'),
            'description' => __('Get all ACF field values for a given post ID as a key-value map.', 'monkbot'),
            'category' => 'monkbot',
            'input_schema' => array(
                'type' => 'object',
                'required' => array('post_id'),
                'properties' => array(
                    'post_id' => array('type' => 'integer', 'description' => 'The post ID.'),
                ),
            ),
            'output_schema' => array('type' => 'string', 'description' => 'JSON map of all ACF field values for the post.'),
            'execute_callback' => function ($input) {
                return monkbot_execute_acf_tool('get_acf_all_fields', (array) $input);
            },
            'permission_callback' => 'monkbot_ability_require_admin',
            'meta' => array('show_in_rest' => true),
        ));
    }
}
add_action('wp_abilities_api_init', 'monkbot_register_all_abilities');

/**
 * Shared execute callback for the get-site-info ability.
 */
function monkbot_ability_get_site_info()
{
    return json_encode(array(
        'site_title' => get_bloginfo('name'),
        'site_description' => get_bloginfo('description'),
    ));
}

/**
 * Shared permission callback: only WordPress admins can execute MonkBot abilities.
 */
function monkbot_ability_require_admin()
{
    return current_user_can('manage_options');
}

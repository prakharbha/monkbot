<?php
/**
 * MonkBot — Security Settings Page
 *
 * Provides a dedicated "Security" submenu page in the WP admin where
 * administrators can control which sensitive AI capabilities are enabled.
 *
 * Options:
 *   monkbot_allow_create_admin   (default: 1) — Allow AI to create administrator accounts
 *   monkbot_allow_query_sensitive (default: 1) — Allow AI to query sensitive tables (wp_users, wp_usermeta)
 */

if (!defined('ABSPATH')) {
    exit;
}

// ─── Register Settings ────────────────────────────────────────────────────────

function monkbot_register_security_settings()
{
    register_setting(
        'monkbot_security_group',
        'monkbot_allow_create_admin',
        array(
            'type' => 'boolean',
            'default' => 1,
            'sanitize_callback' => 'absint',
        )
    );

    register_setting(
        'monkbot_security_group',
        'monkbot_allow_query_sensitive',
        array(
            'type' => 'boolean',
            'default' => 1,
            'sanitize_callback' => 'absint',
        )
    );

    add_settings_section(
        'monkbot_security_main_section',
        'AI Tool Permissions',
        'monkbot_security_section_cb',
        'monkbot_security'
    );

    add_settings_field(
        'monkbot_allow_create_admin',
        'Allow Creating Administrator Accounts',
        'monkbot_allow_create_admin_render',
        'monkbot_security',
        'monkbot_security_main_section'
    );

    add_settings_field(
        'monkbot_allow_query_sensitive',
        'Allow Querying User Hashes & Sensitive Tables',
        'monkbot_allow_query_sensitive_render',
        'monkbot_security',
        'monkbot_security_main_section'
    );
}
add_action('admin_init', 'monkbot_register_security_settings');

// ─── Section Description ──────────────────────────────────────────────────────

function monkbot_security_section_cb()
{
    echo '<p>Control which sensitive actions MonkBot\'s AI is allowed to perform. These settings are <strong>on by default</strong>. Disable any capability you do not want the AI to be able to execute, even when requested by an admin session.</p>';
    echo '<p style="padding: 8px 12px; background: #fff3cd; border-left: 4px solid #ffc107; color: #856404; max-width: 680px;">⚠️ <strong>Prompt Injection Note:</strong> Even with admin-only access, malicious content in posts or comments could instruct the AI to perform these actions. Disabling capabilities you don\'t actively need is a best practice.</p>';
}

// ─── Field Renderers ──────────────────────────────────────────────────────────

function monkbot_allow_create_admin_render()
{
    $val = get_option('monkbot_allow_create_admin', 1);
    echo '<label>';
    echo '<input type="checkbox" name="monkbot_allow_create_admin" value="1" ' . checked(1, $val, false) . '>';
    echo ' <strong>Enabled</strong>';
    echo '</label>';
    echo '<p class="description" style="max-width:560px;">When enabled, the AI can create WordPress user accounts with any role, <strong>including <code>administrator</code></strong>. Disable this to restrict the AI to creating <code>subscriber</code>-level accounts only.</p>';
}

function monkbot_allow_query_sensitive_render()
{
    $val = get_option('monkbot_allow_query_sensitive', 1);
    echo '<label>';
    echo '<input type="checkbox" name="monkbot_allow_query_sensitive" value="1" ' . checked(1, $val, false) . '>';
    echo ' <strong>Enabled</strong>';
    echo '</label>';
    echo '<p class="description" style="max-width:560px;">When enabled, the AI can run SELECT queries against <code>wp_users</code>, <code>wp_usermeta</code>, and other sensitive tables — including retrieving password hashes. Disable this to block reads from those tables entirely.</p>';
}

// ─── Submenu Page Registration ────────────────────────────────────────────────

function monkbot_security_settings_menu()
{
    add_submenu_page(
        'monkbot',
        'MonkBot Security',
        'Security',
        'manage_options',
        'monkbot-security',
        'monkbot_security_page_callback'
    );
}
add_action('admin_menu', 'monkbot_security_settings_menu');

// ─── Page Render ──────────────────────────────────────────────────────────────

function monkbot_security_page_callback()
{
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('You do not have permission to access this page.', 'monkbot'));
    }

    // Determine the overall security posture for the badge
    $allow_admin = get_option('monkbot_allow_create_admin', 1);
    $allow_query = get_option('monkbot_allow_query_sensitive', 1);
    $risks = (int) $allow_admin + (int) $allow_query;
    if ($risks === 0) {
        $badge_color = '#2ea44f';
        $badge_text = '🔒 Hardened';
    } elseif ($risks === 1) {
        $badge_color = '#e36209';
        $badge_text = '⚠️ Partial Risk';
    } else {
        $badge_color = '#d73a49';
        $badge_text = '🔓 Full Access';
    }
    ?>
    <div class="wrap">
        <h1>
            MonkBot Security
            <span style="
                font-size: 12px; font-weight: 600; padding: 3px 10px;
                border-radius: 20px; margin-left: 10px; vertical-align: middle;
                background: <?php echo esc_attr($badge_color); ?>;
                color: #fff;
            ">
                <?php echo esc_html($badge_text); ?>
            </span>
        </h1>

        <p style="color:#646970; max-width: 680px;">
            The settings below control which sensitive AI capabilities are active.
            Changes take effect immediately for all future chat sessions.
        </p>

        <?php settings_errors('monkbot_security_group'); ?>

        <form method="post" action="options.php">
            <?php
            settings_fields('monkbot_security_group');
            do_settings_sections('monkbot_security');
            submit_button('Save Security Settings');
            ?>
        </form>

        <!-- Capability Status Summary -->
        <hr style="margin-top: 30px;">
        <h2>Current Capability Summary</h2>
        <table class="wp-list-table widefat fixed striped" style="max-width: 680px;">
            <thead>
                <tr>
                    <th>Capability</th>
                    <th>Status</th>
                    <th>Risk Level</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><strong>Create Administrator Accounts</strong><br><span style="color:#646970; font-size:12px;">AI
                            can create WP users with the <code>administrator</code> role</span></td>
                    <td>
                        <?php echo $allow_admin ? '<span style="color:#d73a49; font-weight:600;">✓ Allowed</span>' : '<span style="color:#2ea44f; font-weight:600;">✗ Blocked</span>'; ?>
                    </td>
                    <td><span style="color:#d73a49;">High</span></td>
                </tr>
                <tr>
                    <td><strong>Query User Password Hashes</strong><br><span style="color:#646970; font-size:12px;">AI can
                            SELECT from <code>wp_users</code> and <code>wp_usermeta</code></span></td>
                    <td>
                        <?php echo $allow_query ? '<span style="color:#d73a49; font-weight:600;">✓ Allowed</span>' : '<span style="color:#2ea44f; font-weight:600;">✗ Blocked</span>'; ?>
                    </td>
                    <td><span style="color:#d73a49;">High</span></td>
                </tr>
            </tbody>
        </table>
    </div>
    <?php
}

<?php
/**
 * Script and Style Enqueues — No Node.js build step required
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Enqueue vanilla JS and CSS on the MonkBot admin page only.
 */
function monkbot_enqueue_scripts($hook_suffix)
{
    // Only load scripts on our specific admin page
    if ('toplevel_page_monkbot' !== $hook_suffix) {
        return;
    }

    // Enqueue our vanilla JS chatbot (no dependencies, no build step)
    wp_enqueue_script(
        'monkbot-chatbot',
        MONKBOT_URL . 'assets/chatbot.js',
        array(), // No React, no wp-scripts dependencies
        MONKBOT_VERSION,
        true // Load in footer
    );

    // Pass REST URL, nonce, and default model to JS
    wp_localize_script('monkbot-chatbot', 'monkbotParams', array(
        'restUrl' => esc_url_raw(rest_url()),
        'nonce' => wp_create_nonce('wp_rest'),
    ));

    // Enqueue the admin CSS
    wp_enqueue_style(
        'monkbot-admin-style',
        MONKBOT_URL . 'assets/admin.css',
        array(),
        MONKBOT_VERSION
    );
}
add_action('admin_enqueue_scripts', 'monkbot_enqueue_scripts');

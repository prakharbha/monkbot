<?php
/**
 * REST API Endpoints for the Chatbot
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Register endpoints.
 */
function monkbot_register_endpoints()
{
    register_rest_route('monkbot/v1', '/chat', array(
        'methods' => WP_REST_Server::CREATABLE,
        'callback' => 'monkbot_handle_chat_request',
        'permission_callback' => 'monkbot_check_permissions',
    ));
}
add_action('rest_api_init', 'monkbot_register_endpoints');

/**
 * Permission callback: only admins can use this for now.
 */
function monkbot_check_permissions($request)
{
    return current_user_can('manage_options');
}

/**
 * Handle the chat completion request.
 */
function monkbot_handle_chat_request(WP_REST_Request $request)
{
    $messages = $request->get_param('messages');

    if (empty($messages) || !is_array($messages)) {
        return new WP_Error('invalid_data', 'Messages array is required.', array('status' => 400));
    }

    $validation = monkbot_validate_saas_access(false);
    if (empty($validation['allowed'])) {
        return rest_ensure_response(array(
            'status' => 'error',
            'reply' => !empty($validation['message'])
                ? $validation['message']
                : 'MonkBot SaaS key/domain validation failed. Please check MonkBot Settings.'
        ));
    }

    // 1. Fetch available tools from our modular system
    $tools = monkbot_get_tools();

    // 2. Prepare payload for OpenAI (handled by SaaS)
    $payload = array(
        'messages' => $messages,
        'tools' => $tools,
        'tool_choice' => 'auto'
    );

    $max_loops = 5;
    $loop_count = 0;

    while ($loop_count < $max_loops) {
        $loop_count++;

        $response = monkbot_saas_chat_completion($payload, 120);

        if (empty($response['ok'])) {
            return rest_ensure_response(array(
                'status' => 'error',
                'reply' => 'MonkBot SaaS request failed: ' . ($response['error'] ?? 'Unknown error')
            ));
        }

        $data = $response['data'] ?? array();

        if (!empty($data['error'])) {
            return rest_ensure_response(array(
                'status' => 'error',
                'reply' => is_array($data['error']) ? ('SaaS API Error: ' . ($data['error']['message'] ?? 'Unknown error')) : ('SaaS API Error: ' . $data['error'])
            ));
        }

        $message = $data['choices'][0]['message'];
        $messages[] = $message;

        // If OpenAI returned a final text response, we are done!
        if (empty($message['tool_calls'])) {
            break;
        }

        // Otherwise, OpenAI wants to execute tools. Let's run them.
        foreach ($message['tool_calls'] as $tool_call) {
            $tool_name = $tool_call['function']['name'];
            $tool_args = json_decode($tool_call['function']['arguments'], true) ?: array();

            // Execute tool using shared logic
            $tool_result = monkbot_execute_tool($tool_name, $tool_args);

            // Append the result of the tool back into the messages
            $messages[] = array(
                'role' => 'tool',
                'tool_call_id' => $tool_call['id'],
                'name' => $tool_name,
                'content' => is_string($tool_result) ? $tool_result : wp_json_encode($tool_result)
            );
        }

        // Update the payload and loop again to send the tool results back to OpenAI
        $payload['messages'] = $messages;
    }

    if ($loop_count >= $max_loops) {
        return rest_ensure_response(array(
            'status' => 'error',
            'reply' => 'OpenAI hit the maximum tool recursion limit (' . $max_loops . ' loops).'
        ));
    }

    return rest_ensure_response(array(
        'status' => 'success',
        'reply' => $message['content'] ?? 'No text response generated.'
    ));
}

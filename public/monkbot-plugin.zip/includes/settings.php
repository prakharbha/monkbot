<?php
/**
 * Settings Page for WP MCP Chatbot
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Register settings and setting fields.
 */
function monkbot_register_settings()
{
    // Register the options
    register_setting('monkbot_settings_group', 'monkbot_api_key', array('type' => 'string', 'sanitize_callback' => 'sanitize_text_field'));

    register_setting('monkbot_settings_group', 'monkbot_telegram_bot_token', array('type' => 'string', 'sanitize_callback' => 'sanitize_text_field'));
    register_setting('monkbot_settings_group', 'monkbot_telegram_chat_id', array('type' => 'string', 'sanitize_callback' => 'sanitize_text_field'));

    // Add core settings section
    add_settings_section(
        'monkbot_core_settings_section',
        'MonkBot SaaS Connection',
        'monkbot_core_settings_section_callback',
        'monkbot_settings'
    );

    // Add telegram settings section
    add_settings_section(
        'monkbot_telegram_settings_section',
        'Telegram Integration',
        'monkbot_telegram_settings_section_callback',
        'monkbot_settings'
    );

    // Add API Key Field
    add_settings_field(
        'monkbot_api_key',
        'MonkBot API Key',
        'monkbot_api_key_render',
        'monkbot_settings',
        'monkbot_core_settings_section'
    );


    // Add Telegram Bot Token Field
    add_settings_field(
        'monkbot_telegram_bot_token',
        'Telegram Bot Token',
        'monkbot_telegram_bot_token_render',
        'monkbot_settings',
        'monkbot_telegram_settings_section'
    );

    // Add Telegram Chat ID Field
    add_settings_field(
        'monkbot_telegram_chat_id',
        'Telegram Chat ID',
        'monkbot_telegram_chat_id_render',
        'monkbot_settings',
        'monkbot_telegram_settings_section'
    );
}
add_action('admin_init', 'monkbot_register_settings');

/**
 * Register Settings Page in Admin Menu
 */
function monkbot_settings_menu()
{
    add_submenu_page(
        'monkbot',
        'MonkBot Settings',
        'Settings',
        'manage_options',
        'monkbot-settings',
        'monkbot_settings_page_callback'
    );
}
add_action('admin_menu', 'monkbot_settings_menu');

/**
 * Core section description callback
 */
function monkbot_core_settings_section_callback()
{
    echo '<p>Connect this site to your MonkBot SaaS account to enable AI features.</p>';
    echo '<ol style="padding-left: 20px; margin-top: 10px; margin-bottom: 20px;">';
    echo '<li>Log in to your <a href="https://monkbot.app/dashboard" target="_blank">MonkBot Dashboard</a>.</li>';
    echo '<li>Navigate to <strong>API Keys</strong> and create a new key.</li>';
    echo '<li>Click <strong>Manage Domains</strong> on that key and add exactly: <code>' . esc_html(monkbot_get_site_domain()) . '</code></li>';
    echo '<li>Copy the Secret Key and paste it in the field below.</li>';
    echo '</ol>';
}

/**
 * Telegram section description callback
 */
function monkbot_telegram_settings_section_callback()
{
    echo '<p>Optionally connect a Telegram bot to interact directly with your WordPress site from Telegram.</p>';
}

/**
 * API Key Field Render
 */
function monkbot_api_key_render()
{
    $api_key = get_option('monkbot_api_key');
    echo "<input type='password' name='monkbot_api_key' style='width: 360px;' value='" . esc_attr($api_key) . "' />";
}

/**
 * Telegram Bot Token Field Render
 */
function monkbot_telegram_bot_token_render()
{
    $bot_token = get_option('monkbot_telegram_bot_token');
    echo "<input type='password' name='monkbot_telegram_bot_token' style='width: 300px;' value='" . esc_attr($bot_token) . "' />";
    echo "<p class='description'>Enter your Telegram Bot Token. Example: <code>123456789:ABCdefGHIjklMNOpqrsTUVwxyz</code></p>";
}

/**
 * Telegram Chat ID Field Render
 */
function monkbot_telegram_chat_id_render()
{
    $chat_id = get_option('monkbot_telegram_chat_id');
    echo "<input type='password' name='monkbot_telegram_chat_id' style='width: 300px;' value='" . esc_attr($chat_id) . "' />";
    echo "<p class='description'>Enter the Chat ID to allow interactions on Telegram.</p>";

    $bot_token = get_option('monkbot_telegram_bot_token');
    echo "<div style='margin-top: 15px; padding: 12px; background: #fff; border-left: 4px solid #2271b1; box-shadow: 0 1px 1px rgba(0,0,0,.04); max-width: 600px;'>";
    echo "<p style='margin-top: 0;'><strong>Note:</strong> For Telegram to send messages here, you must register this webhook.</p>";

    if (!empty($bot_token)) {
        // Include the secret token in the registration URL so Telegram will send it back on each request
        $secret = monkbot_get_or_create_telegram_secret();
        $wh_url = rest_url('monkbot/v1/telegram-webhook');
        $reg_url = 'https://api.telegram.org/bot' . rawurlencode($bot_token) . '/setWebhook?url=' . rawurlencode($wh_url) . '&secret_token=' . rawurlencode($secret);
        echo "<a href='" . esc_url($reg_url) . "' target='_blank' class='button button-secondary'>Click here to register webhook with Telegram</a>";
        echo "<p style='margin-top:8px; font-size:12px; color:#646970;'>⚠️ This URL contains your bot token — do not share it. It opens in a new tab and returns a Telegram API confirmation.</p>";
    } else {
        echo "<p style='margin-bottom: 0; color: #d63638;'><em>Please enter and save your Telegram Bot Token above to generate your registration link.</em></p>";
    }
    echo "</div>";
}

/**
 * Page Callback
 */
function monkbot_settings_page_callback()
{
    // Capability check (defence-in-depth — menu already requires manage_options)
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('You do not have permission to access this page.', 'monkbot'));
    }
    ?>
    <div class="wrap">
        <h1>MonkBot Settings</h1>

        <form method="post" action="options.php">
            <?php
            settings_fields('monkbot_settings_group');
            do_settings_sections('monkbot_settings');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

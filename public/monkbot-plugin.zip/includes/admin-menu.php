<?php
/**
 * Admin Menu and Chat Page — Pure PHP Rendered UI
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Register the admin menu page.
 */
function monkbot_add_admin_menu()
{
    add_menu_page(
        'MonkBot',
        'MonkBot',
        'manage_options',
        'monkbot',
        'monkbot_admin_page_contents',
        'dashicons-format-chat',
        30
    );
}
add_action('admin_menu', 'monkbot_add_admin_menu');

/**
 * Render the admin page with the full PHP chatbot UI.
 */
function monkbot_admin_page_contents()
{

    ?>
    <div class="wrap monkbot-wrap">
        <h1>
            <span class="dashicons dashicons-format-chat"
                style="font-size:1em; vertical-align:middle; margin-right:8px;"></span>
            MonkBot
            <span style="font-size:13px; font-weight:400; color:#646970; margin-left:12px;">AI Site Assistant</span>
        </h1>

        <div class="monkbot-chat-container monkbot-card">

            <!-- Chat Header -->
            <div class="monkbot-chat-header">
                <div class="monkbot-chat-header-info">
                    <span class="monkbot-status-dot"></span>
                    <strong>MonkBot</strong>
                    <span class="monkbot-status-text">Online</span>
                </div>

            </div>

            <!-- Message List -->
            <div class="monkbot-message-list" id="monkbot-messages" role="log" aria-live="polite">
                <!-- Messages rendered by chatbot.js -->
            </div>

            <!-- Input Area -->
            <div class="monkbot-input-area">
                <button id="monkbot-mic" class="monkbot-btn-icon" title="Start voice input" aria-label="Voice input">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                        <path
                            d="M12 15c1.66 0 3-1.34 3-3V6c0-1.66-1.34-3-3-3S9 4.34 9 6v6c0 1.66 1.34 3 3 3zm-1-9c0-.55.45-1 1-1s1 .45 1 1v6c0 .55-.45 1-1 1s-1-.45-1-1V6zm6 6c0 2.76-2.24 5-5 5s-5-2.24-5-5H5c0 3.53 2.61 6.43 6 6.92V21h2v-2.08c3.39-.49 6-3.39 6-6.92h-2z" />
                    </svg>
                </button>
                <input type="text" id="monkbot-input" placeholder="Ask MonkBot anything about your site…" autocomplete="off"
                    aria-label="Message input" />
                <button id="monkbot-send" class="monkbot-btn" aria-label="Send message">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="currentColor"
                        style="margin-right:4px;">
                        <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z" />
                    </svg>
                    Send
                </button>
            </div>

        </div><!-- .monkbot-chat-container -->
    </div><!-- .monkbot-wrap -->
    <?php
}

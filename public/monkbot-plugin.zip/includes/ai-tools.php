<?php
/**
 * Master AI Tools Bridge — MonkBot
 *
 * Bridges the WordPress 6.9 Abilities API with OpenAI's function-calling format.
 * When WP Abilities API is available, this file reads from the WP Ability Registry
 * and converts each registered MonkBot ability into an OpenAI-compatible tool definition.
 * This ensures no duplication: abilities are registered once in abilities.php, and this
 * file auto-generates the OpenAI format from them at runtime.
 *
 * Falls back to the legacy static tool array for WP < 6.9.
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Returns the aggregated list of tools in OpenAI function-calling format.
 * Reads from the WP 6.9 Abilities Registry if available, with a legacy fallback.
 */
function monkbot_get_tools()
{
    // --- WP 6.9+ PATH: Read directly from the Abilities API ---
    if (function_exists('wp_get_abilities')) {
        // Ensure abilities are registered (since REST API often triggers before the hook fires)
        if (!did_action('wp_abilities_api_categories_init')) {
            do_action('wp_abilities_api_categories_init');
        }
        if (!did_action('wp_abilities_api_init')) {
            do_action('wp_abilities_api_init');
        }

        $abilities = wp_get_abilities();
        $tools = array();

        foreach ($abilities as $id => $ability) {
            // Only expose MonkBot's own abilities
            if (strpos($id, 'monkbot/') !== 0) {
                continue;
            }

            // Use the proper WP_Ability public API to get the input schema
            $parameters = $ability->get_input_schema();
            if (empty($parameters)) {
                $parameters = array('type' => 'object', 'properties' => new stdClass());
            }

            // Convert namespaced ability ID (monkbot/list-posts) to OpenAI-safe name
            // e.g. monkbot/list-posts → monkbot__list_posts
            $openai_name = str_replace(array('/', '-'), array('__', '_'), $id);

            $tools[] = array(
                'type' => 'function',
                'function' => array(
                    'name' => $openai_name,
                    'description' => $ability->get_description(),
                    'parameters' => $parameters,
                ),
            );
        }

        if (!empty($tools)) {
            return $tools;
        }
    }

    // --- LEGACY FALLBACK for WP < 6.9 ---
    $tools = array();

    $tools[] = array(
        'type' => 'function',
        'function' => array(
            'name' => 'get_wordpress_site_info',
            'description' => 'Get basic information about the current WordPress site.',
            'parameters' => array('type' => 'object', 'properties' => new stdClass()),
        ),
    );

    if (function_exists('monkbot_get_posts_tools')) {
        $tools = array_merge($tools, monkbot_get_posts_tools());
    }
    if (function_exists('monkbot_get_users_tools')) {
        $tools = array_merge($tools, monkbot_get_users_tools());
    }
    if (function_exists('monkbot_get_comments_tools')) {
        $tools = array_merge($tools, monkbot_get_comments_tools());
    }
    if (function_exists('monkbot_get_system_tools')) {
        $tools = array_merge($tools, monkbot_get_system_tools());
    }
    if (function_exists('monkbot_get_woocommerce_tools')) {
        $tools = array_merge($tools, monkbot_get_woocommerce_tools());
    }

    return $tools;
}

/**
 * Executes a tool by name and returns the JSON-encoded result.
 *
 * Converts the OpenAI snake_case tool name back to a WP Ability ID and
 * dispatches execution through the WP Ability Registry. Falls back to the
 * legacy module dispatcher for WP < 6.9.
 *
 * @param string $tool_name  The OpenAI function name.
 * @param array  $arguments  Decoded function arguments from OpenAI.
 * @return string JSON-encoded result.
 */
function monkbot_execute_tool($tool_name, $arguments = array())
{
    // Convert OpenAI function name back to WP Ability ID
    // e.g.  monkbot__list_posts → monkbot/list-posts
    $ability_id = str_replace(array('__', '_'), array('/', '-'), $tool_name);

    // --- WP 6.9+ PATH: Execute via Abilities API ---
    $ability_id = str_replace(array('__', '_'), array('/', '-'), $tool_name);

    if (function_exists('wp_has_ability') && wp_has_ability($ability_id)) {
        $ability = wp_get_ability($ability_id);

        if ($ability instanceof WP_Ability) {
            // Use the official check_permissions() method
            $permission = $ability->check_permissions((object) $arguments);
            if (is_wp_error($permission) || $permission === false) {
                return json_encode(array('error' => 'Permission denied.'));
            }

            // Use the official execute() method
            $result = $ability->execute((object) $arguments);

            if (is_wp_error($result)) {
                return json_encode(array('error' => $result->get_error_message()));
            }

            return is_string($result) ? $result : json_encode($result);
        }
    }

    // --- LEGACY FALLBACK for WP < 6.9 ---
    if ($tool_name === 'get_wordpress_site_info') {
        return json_encode(array(
            'site_title' => get_bloginfo('name'),
            'site_description' => get_bloginfo('description'),
        ));
    }

    $modules = array(
        'monkbot_execute_posts_tool',
        'monkbot_execute_users_tool',
        'monkbot_execute_comments_tool',
        'monkbot_execute_system_tool',
        'monkbot_execute_woocommerce_tool',
        'monkbot_execute_hooks_tool',
        'monkbot_execute_database_tool',
        'monkbot_execute_shell_tool',
        'monkbot_execute_acf_tool',
    );

    foreach ($modules as $fn) {
        if (function_exists($fn)) {
            $result = $fn($tool_name, $arguments);
            if ($result !== false) {
                return $result;
            }
        }
    }

    return json_encode(array('error' => "Tool '$tool_name' is not implemented."));
}

<?php
if (!defined('ABSPATH')) {
    exit;
}

function monkbot_get_comments_tools()
{
    return array(
        array(
            'type' => 'function',
            'function' => array(
                'name' => 'list_comments',
                'description' => 'Retrieve a list of comments on the site.',
                'parameters' => array(
                    'type' => 'object',
                    'properties' => array(
                        'status' => array('type' => 'string', 'description' => 'Status (approve, hold, spam, trash). Default: all'),
                        'number' => array('type' => 'integer', 'description' => 'Number of comments to return. Default: 10'),
                        'offset' => array('type' => 'integer', 'description' => 'Offset for pagination. Default: 0'),
                    )
                )
            )
        ),
        array(
            'type' => 'function',
            'function' => array(
                'name' => 'update_comment_status',
                'description' => 'Update the status of a specific comment.',
                'parameters' => array(
                    'type' => 'object',
                    'required' => array('comment_id', 'status'),
                    'properties' => array(
                        'comment_id' => array('type' => 'integer', 'description' => 'The comment ID.'),
                        'status' => array('type' => 'string', 'description' => 'New status (approve, hold, spam, trash).'),
                    )
                )
            )
        ),
        array(
            'type' => 'function',
            'function' => array(
                'name' => 'delete_comment',
                'description' => 'Permanently delete a comment.',
                'parameters' => array(
                    'type' => 'object',
                    'required' => array('comment_id'),
                    'properties' => array(
                        'comment_id' => array('type' => 'integer', 'description' => 'The comment ID to delete.'),
                        'force_delete' => array('type' => 'boolean', 'description' => 'Bypass trash and force delete. Default: false')
                    )
                )
            )
        )
    );
}

function monkbot_execute_comments_tool($tool_name, $arguments)
{
    switch ($tool_name) {
        case 'list_comments':
            $args = array(
                'number' => absint($arguments['number'] ?? 10),
                'offset' => absint($arguments['offset'] ?? 0),
            );
            if (!empty($arguments['status']) && $arguments['status'] !== 'all') {
                $args['status'] = $arguments['status'];
            }

            $comments_query = new WP_Comment_Query($args);
            $comments = $comments_query->comments;
            $comments_data = array();

            foreach ($comments as $c) {
                $comments_data[] = array(
                    'id' => $c->comment_ID,
                    'post_id' => $c->comment_post_ID,
                    'author' => $c->comment_author,
                    'content' => $c->comment_content,
                    'status' => $c->comment_approved,
                    'date' => $c->comment_date
                );
            }
            return json_encode(array('comments' => $comments_data));

        case 'update_comment_status':
            $comment_id = intval($arguments['comment_id']);
            $allowed_statuses = array('approve', 'hold', 'spam', 'trash');
            $status = in_array($arguments['status'], $allowed_statuses, true) ? $arguments['status'] : 'hold';

            $result = wp_set_comment_status($comment_id, $status);
            if (is_wp_error($result)) {
                return json_encode(array('error' => $result->get_error_message()));
            }
            if ($result) {
                return json_encode(array('message' => "Successfully updated comment $comment_id to status $status."));
            } else {
                return json_encode(array('error' => "Failed to update comment $comment_id status."));
            }

        case 'delete_comment':
            $comment_id = intval($arguments['comment_id']);
            $force = $arguments['force_delete'] ?? false;

            $result = wp_delete_comment($comment_id, $force);
            if ($result) {
                return json_encode(array('message' => "Successfully deleted comment ID $comment_id."));
            } else {
                return json_encode(array('error' => "Failed to delete comment ID $comment_id."));
            }
    }
    return false;
}

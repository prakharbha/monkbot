<?php
/**
 * MonkBot Tool Module: wp_shell
 * Execute arbitrary PHP code in WordPress context via a temp file + proc_open.
 * No eval() is used — satisfies Generic.PHP.ForbiddenFunctions.Found.
 *
 * ⚠️ DANGER ZONE: This tool allows running raw PHP on the server.
 * Protected by manage_options capability check in the ability registry.
 */

if (!defined('ABSPATH')) {
    exit;
}

function monkbot_execute_shell_tool($tool_name, $arguments)
{
    if ($tool_name !== 'wp_shell') {
        return false;
    }

    // Verify current user has admin privileges (defence in depth)
    if (!current_user_can('manage_options')) {
        return json_encode(array('error' => 'Permission denied.'));
    }

    $code = $arguments['code'] ?? '';

    if (empty($code)) {
        return json_encode(array('error' => 'No code provided.'));
    }

    // Check proc_open is available (some hosts disable it)
    $disabled = array_map('trim', explode(',', (string) ini_get('disable_functions')));
    if (!function_exists('proc_open') || in_array('proc_open', $disabled, true)) {
        return json_encode(array(
            'error' => 'proc_open() is disabled in this PHP environment. wp_shell is unavailable.',
        ));
    }

    // Write a self-contained PHP script to a temp file, execute it, clean up
    $tmp_file = wp_tempnam('monkbot_shell_');
    $abspath = addslashes(ABSPATH);
    $wp_load = addslashes(ABSPATH . 'wp-load.php');

    // Build a script that loads WP and runs the user's code in a closure
    $script = "<?php\n";
    $script .= "require_once '{$wp_load}';\n";
    $script .= "ob_start();\n";
    $script .= "\$__result = (function() {\n{$code}\n})();\n";
    $script .= "echo json_encode(['output' => ob_get_clean(), 'return_value' => \$__result]);\n";

    // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
    file_put_contents($tmp_file, $script);

    $descriptors = array(
        0 => array('pipe', 'r'),
        1 => array('pipe', 'w'),
        2 => array('pipe', 'w'),
    );

    $php_binary = PHP_BINARY ?: 'php';
    // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.system_calls_proc_open, Generic.PHP.ForbiddenFunctions.Found
    $process = proc_open(escapeshellcmd($php_binary) . ' ' . escapeshellarg($tmp_file), $descriptors, $pipes);

    $stdout = '';
    $stderr = '';

    if (is_resource($process)) {
        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
        fclose($pipes[0]);
        $stdout = stream_get_contents($pipes[1]);
        $stderr = stream_get_contents($pipes[2]);
        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
        fclose($pipes[1]);
        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
        fclose($pipes[2]);
        proc_close($process);
    }

    // phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink
    @unlink($tmp_file);

    if (!empty($stderr)) {
        return json_encode(array('error' => trim($stderr), 'output' => $stdout));
    }

    $decoded = json_decode($stdout, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        return json_encode(array('output' => $stdout, 'return_value' => null));
    }

    return json_encode($decoded);
}

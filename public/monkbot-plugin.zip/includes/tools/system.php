<?php
if (!defined('ABSPATH')) {
    exit;
}

function monkbot_get_system_tools()
{
    return array(
        array(
            'type' => 'function',
            'function' => array(
                'name' => 'list_updates_required',
                'description' => 'Checks if any installed WordPress plugins or themes have an update available. Returns a list of extensions that need updates.',
                'parameters' => array(
                    'type' => 'object',
                    'properties' => new stdClass(),
                )
            )
        ),
        array(
            'type' => 'function',
            'function' => array(
                'name' => 'deactivate_plugin',
                'description' => 'Deactivate a specific plugin.',
                'parameters' => array(
                    'type' => 'object',
                    'required' => array('plugin_file'),
                    'properties' => array(
                        'plugin_file' => array('type' => 'string', 'description' => 'The plugin file path relative to plugins dir (e.g., akismet/akismet.php). Use list_updates_required to find exact names.'),
                    )
                )
            )
        )
        // Note: Actively updating plugins via WP_Upgrader API requires complex filesystem credentials handling.
        // It's safer to just inform the user what needs updating and let them click 'update' in the Dashboard.
        // Or if we run CLI, we could do `shell_exec('wp plugin update --all')` but that relies on server environment.
    );
}

function monkbot_execute_system_tool($tool_name, $arguments)
{
    switch ($tool_name) {
        case 'list_updates_required':
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
            wp_update_plugins();
            $update_plugins = get_site_transient('update_plugins');
            $updates_needed = array();

            if (isset($update_plugins->response) && is_array($update_plugins->response)) {
                $plugins = get_plugins();
                foreach ($update_plugins->response as $plugin_file => $plugin_data) {
                    $plugin_name = isset($plugins[$plugin_file]) ? $plugins[$plugin_file]['Name'] : $plugin_file;
                    $updates_needed[] = array(
                        'plugin_name' => $plugin_name,
                        'plugin_file' => $plugin_file,
                        'current_version' => isset($plugins[$plugin_file]['Version']) ? $plugins[$plugin_file]['Version'] : 'Unknown',
                        'new_version' => $plugin_data->new_version
                    );
                }
            }
            return json_encode(array(
                'plugins_needing_update' => $updates_needed,
                'total_updates' => count($updates_needed)
            ));

        case 'deactivate_plugin':
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
            $plugin = sanitize_text_field($arguments['plugin_file']);

            if (is_plugin_active($plugin)) {
                deactivate_plugins($plugin);
                return json_encode(array('message' => "Successfully deactivated plugin: $plugin"));
            } else {
                return json_encode(array('error' => "Plugin $plugin is not active or does not exist."));
            }
    }
    return false;
}

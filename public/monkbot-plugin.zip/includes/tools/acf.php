<?php
/**
 * MonkBot Tool Module: ACF Integration
 * Read ACF field groups and field values (requires Advanced Custom Fields).
 */

if (!defined('ABSPATH')) {
    exit;
}

function monkbot_execute_acf_tool($tool_name, $arguments)
{
    if (!function_exists('acf_get_field_groups')) {
        return json_encode(array('error' => 'Advanced Custom Fields (ACF) is not active.'));
    }

    switch ($tool_name) {

        case 'list_acf_field_groups':
            $groups = acf_get_field_groups();
            $group_data = array();

            foreach ($groups as $group) {
                $group_data[] = array(
                    'key' => $group['key'],
                    'title' => $group['title'],
                    'active' => $group['active'],
                    'location' => $group['location'] ?? array(),
                );
            }

            return json_encode(array(
                'total' => count($group_data),
                'field_groups' => $group_data,
            ));

        case 'list_acf_fields':
            $group_key = sanitize_text_field($arguments['group_key'] ?? '');

            if (empty($group_key)) {
                return json_encode(array('error' => 'group_key is required. Use list_acf_field_groups to find it.'));
            }

            $fields = acf_get_fields($group_key);
            if (empty($fields)) {
                return json_encode(array('error' => "No fields found for group key '$group_key'."));
            }

            $field_data = array();
            foreach ($fields as $field) {
                $field_data[] = array(
                    'key' => $field['key'],
                    'name' => $field['name'],
                    'label' => $field['label'],
                    'type' => $field['type'],
                    'required' => $field['required'] ?? false,
                    'instructions' => $field['instructions'] ?? '',
                );
            }

            return json_encode(array(
                'group_key' => $group_key,
                'fields' => $field_data,
            ));

        case 'get_acf_field_value':
            $post_id = intval($arguments['post_id'] ?? 0);
            $field_name = sanitize_text_field($arguments['field_name'] ?? '');

            if (!$post_id || empty($field_name)) {
                return json_encode(array('error' => 'Both post_id and field_name are required.'));
            }

            $value = get_field($field_name, $post_id);

            return json_encode(array(
                'post_id' => $post_id,
                'field_name' => $field_name,
                'value' => $value,
            ));

        case 'get_acf_all_fields':
            $post_id = intval($arguments['post_id'] ?? 0);
            if (!$post_id) {
                return json_encode(array('error' => 'post_id is required.'));
            }

            $fields = get_fields($post_id);

            return json_encode(array(
                'post_id' => $post_id,
                'fields' => $fields ?: array(),
            ));
    }

    return false;
}

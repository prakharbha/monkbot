<?php
/**
 * MonkBot Tool Module: Hooks Introspection
 * Lists WordPress actions, filters, and their callbacks.
 */

if (!defined('ABSPATH')) {
    exit;
}

function monkbot_execute_hooks_tool($tool_name, $arguments)
{
    global $wp_filter;

    switch ($tool_name) {

        case 'list_hooks':
            $search = !empty($arguments['search']) ? strtolower($arguments['search']) : '';
            $type = $arguments['type'] ?? 'all'; // all, action, filter
            $limit = min(absint($arguments['limit'] ?? 50), 200);
            $hooks = array();
            $count = 0;

            foreach ($wp_filter as $hook_name => $hook_obj) {
                if ($search && strpos($hook_name, $search) === false) {
                    continue;
                }
                // WordPress doesn't natively distinguish actions from filters in storage;
                // we use a heuristic: actions typically have no return value usage,
                // but since the registry is shared, we just expose hook names + callback count.
                $hooks[] = array(
                    'hook' => $hook_name,
                    'callback_count' => count($hook_obj->callbacks, COUNT_RECURSIVE),
                    'priority_levels' => array_keys($hook_obj->callbacks),
                );
                $count++;
                if ($count >= $limit)
                    break;
            }

            return json_encode(array(
                'total_shown' => count($hooks),
                'note' => 'Limited to ' . $limit . ' results. Use "search" param to filter.',
                'hooks' => $hooks,
            ));

        case 'get_hook_callbacks':
            $hook_name = sanitize_text_field($arguments['hook'] ?? '');
            if (empty($hook_name) || !isset($wp_filter[$hook_name])) {
                return json_encode(array('error' => "Hook '$hook_name' not found in the registry."));
            }

            $hook_obj = $wp_filter[$hook_name];
            $priorities = array();

            foreach ($hook_obj->callbacks as $priority => $callbacks) {
                $cbs = array();
                foreach ($callbacks as $cb) {
                    $func = $cb['function'];
                    if (is_string($func)) {
                        $cbs[] = $func;
                    } elseif (is_array($func) && count($func) === 2) {
                        $obj = is_object($func[0]) ? get_class($func[0]) : $func[0];
                        $cbs[] = $obj . '::' . $func[1];
                    } elseif ($func instanceof Closure) {
                        $cbs[] = '[Closure]';
                    } else {
                        $cbs[] = '[Unknown callable]';
                    }
                }
                $priorities[$priority] = $cbs;
            }

            return json_encode(array(
                'hook' => $hook_name,
                'priorities' => $priorities,
            ));

        case 'search_hooks':
            $keyword = strtolower(sanitize_text_field($arguments['keyword'] ?? ''));
            if (empty($keyword)) {
                return json_encode(array('error' => 'A keyword is required.'));
            }

            $matches = array();
            foreach ($wp_filter as $hook_name => $hook_obj) {
                if (strpos($hook_name, $keyword) !== false) {
                    $matches[] = array(
                        'hook' => $hook_name,
                        'callback_count' => count($hook_obj->callbacks, COUNT_RECURSIVE),
                    );
                }
                if (count($matches) >= 100)
                    break;
            }

            return json_encode(array(
                'keyword' => $keyword,
                'results' => count($matches),
                'hooks' => $matches,
            ));
    }

    return false;
}

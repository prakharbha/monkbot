<?php
if (!defined('ABSPATH')) {
    exit;
}

function monkbot_get_posts_tools()
{
    return array(
        array(
            'type' => 'function',
            'function' => array(
                'name' => 'list_posts',
                'description' => 'Retrieve a list of posts, pages, or custom post types.',
                'parameters' => array(
                    'type' => 'object',
                    'properties' => array(
                        'post_type' => array('type' => 'string', 'description' => 'Post type (e.g., post, page). Default: any'),
                        'number' => array('type' => 'integer', 'description' => 'Number of posts to return. Default: 10'),
                        'offset' => array('type' => 'integer', 'description' => 'Offset for pagination. Default: 0'),
                    )
                )
            )
        ),
        array(
            'type' => 'function',
            'function' => array(
                'name' => 'create_or_update_post',
                'description' => 'Create a new post or update an existing one if ID is provided.',
                'parameters' => array(
                    'type' => 'object',
                    'required' => array('title', 'content'),
                    'properties' => array(
                        'post_id' => array('type' => 'integer', 'description' => 'ID of the post to update. Leave empty to create new.'),
                        'title' => array('type' => 'string', 'description' => 'The title of the post.'),
                        'content' => array('type' => 'string', 'description' => 'The post content.'),
                        'post_type' => array('type' => 'string', 'description' => 'Post type (e.g., post, page). Default: post'),
                        'status' => array('type' => 'string', 'description' => 'Publish status (publish, draft, pending). Default: draft'),
                    )
                )
            )
        ),
        array(
            'type' => 'function',
            'function' => array(
                'name' => 'delete_post',
                'description' => 'Delete a post entirely.',
                'parameters' => array(
                    'type' => 'object',
                    'required' => array('post_id'),
                    'properties' => array(
                        'post_id' => array('type' => 'integer', 'description' => 'ID of the post to delete.'),
                        'force_delete' => array('type' => 'boolean', 'description' => 'Whether to bypass trash and force delete. Default: false')
                    )
                )
            )
        )
    );
}

function monkbot_execute_posts_tool($tool_name, $arguments)
{
    switch ($tool_name) {
        case 'list_posts':
            $args = array(
                'post_type' => sanitize_key($arguments['post_type'] ?? 'any'),
                'posts_per_page' => absint($arguments['number'] ?? 10),
                'offset' => absint($arguments['offset'] ?? 0),
            );
            $query = new WP_Query($args);
            $posts_data = array();
            foreach ($query->posts as $p) {
                $posts_data[] = array(
                    'id' => $p->ID,
                    'title' => $p->post_title,
                    'type' => $p->post_type,
                    'status' => $p->post_status,
                    'url' => get_permalink($p->ID),
                    'edit_link' => get_edit_post_link($p->ID, 'raw')
                );
            }
            return json_encode(array('total' => $query->found_posts, 'posts' => $posts_data));

        case 'create_or_update_post':
            $post_data = array(
                'post_title' => wp_strip_all_tags($arguments['title']),
                'post_content' => wp_kses_post($arguments['content']),
                'post_type' => sanitize_key($arguments['post_type'] ?? 'post'),
                'post_status' => sanitize_key($arguments['status'] ?? 'draft'),
            );

            if (!empty($arguments['post_id'])) {
                $post_data['ID'] = intval($arguments['post_id']);
                $result = wp_update_post($post_data);
                $action = 'updated';
            } else {
                $result = wp_insert_post($post_data);
                $action = 'created';
            }

            if (is_wp_error($result)) {
                return json_encode(array('error' => $result->get_error_message()));
            }
            return json_encode(array(
                'message' => "Successfully $action post.",
                'post_id' => $result,
                'url' => get_permalink($result),
                'edit_link' => get_edit_post_link($result, 'raw')
            ));

        case 'delete_post':
            $post_id = intval($arguments['post_id']);
            $force = $arguments['force_delete'] ?? false;
            $result = wp_delete_post($post_id, $force);

            if ($result) {
                return json_encode(array('message' => "Successfully deleted post ID $post_id."));
            } else {
                return json_encode(array('error' => "Failed to delete post ID $post_id."));
            }
    }
    return false; // Tool not handled
}

<?php
if (!defined('ABSPATH')) {
    exit;
}

function monkbot_get_woocommerce_tools()
{
    return array(
        array(
            'type' => 'function',
            'function' => array(
                'name' => 'list_wc_products',
                'description' => 'Retrieve a list of WooCommerce products.',
                'parameters' => array(
                    'type' => 'object',
                    'properties' => array(
                        'status' => array('type' => 'string', 'description' => 'Status (publish, draft). Default: publish'),
                        'limit' => array('type' => 'integer', 'description' => 'Number of products to return. Default: 10'),
                        'offset' => array('type' => 'integer', 'description' => 'Offset for pagination. Default: 0'),
                    )
                )
            )
        ),
        array(
            'type' => 'function',
            'function' => array(
                'name' => 'update_wc_product_price',
                'description' => 'Update the regular or sale price of a WooCommerce product.',
                'parameters' => array(
                    'type' => 'object',
                    'required' => array('product_id'),
                    'properties' => array(
                        'product_id' => array('type' => 'integer', 'description' => 'The product ID.'),
                        'regular_price' => array('type' => 'string', 'description' => 'New regular price. Leave empty to skip.'),
                        'sale_price' => array('type' => 'string', 'description' => 'New sale price. Leave empty to skip. Set to "clear" to remove sale price.')
                    )
                )
            )
        ),
        array(
            'type' => 'function',
            'function' => array(
                'name' => 'list_wc_orders',
                'description' => 'Retrieve a list of WooCommerce orders.',
                'parameters' => array(
                    'type' => 'object',
                    'properties' => array(
                        'status' => array('type' => 'string', 'description' => 'Order status (e.g., pending, processing, completed, cancelled). Default: any'),
                        'limit' => array('type' => 'integer', 'description' => 'Number of orders to return. Default: 10'),
                    )
                )
            )
        ),
        array(
            'type' => 'function',
            'function' => array(
                'name' => 'update_wc_order_status',
                'description' => 'Update the status of a WooCommerce order.',
                'parameters' => array(
                    'type' => 'object',
                    'required' => array('order_id', 'status'),
                    'properties' => array(
                        'order_id' => array('type' => 'integer', 'description' => 'The order ID.'),
                        'status' => array('type' => 'string', 'description' => 'New status (pending, processing, on-hold, completed, cancelled, refunded, failed).')
                    )
                )
            )
        ),
        array(
            'type' => 'function',
            'function' => array(
                'name' => 'wc_revenue_summary',
                'description' => 'Get total orders, total revenue, and average order value for a given period.',
                'parameters' => array(
                    'type' => 'object',
                    'properties' => array(
                        'days' => array('type' => 'integer', 'description' => 'Number of days to look back. Default: 30, max: 365.')
                    )
                )
            )
        ),
        array(
            'type' => 'function',
            'function' => array(
                'name' => 'wc_top_products',
                'description' => 'List the best-selling products by revenue for a given period. Use order_by=qty_sold and order=asc to find least sold products.',
                'parameters' => array(
                    'type' => 'object',
                    'properties' => array(
                        'days' => array('type' => 'integer', 'description' => 'Days to look back. Default: 30.'),
                        'limit' => array('type' => 'integer', 'description' => 'Number of top products to return. Default: 10.'),
                        'order_by' => array('type' => 'string', 'description' => 'Sort by revenue or qty_sold. Default: revenue'),
                        'order' => array('type' => 'string', 'description' => 'Sort direction desc or asc. Default: desc'),
                    )
                )
            )
        ),
        array(
            'type' => 'function',
            'function' => array(
                'name' => 'wc_category_breakdown',
                'description' => 'Show revenue and quantity sold broken down by WooCommerce product category.',
                'parameters' => array(
                    'type' => 'object',
                    'properties' => array(
                        'days' => array('type' => 'integer', 'description' => 'Days to look back. Default: 30.')
                    )
                )
            )
        ),
        array(
            'type' => 'function',
            'function' => array(
                'name' => 'wc_revenue_by_region',
                'description' => 'Show order counts and revenue broken down by customer billing country, state, or region. Use this to answer queries like "which country has the most sales?".',
                'parameters' => array(
                    'type' => 'object',
                    'properties' => array(
                        'days' => array('type' => 'integer', 'description' => 'Days to look back. Default: 30.')
                    )
                )
            )
        ),
        array(
            'type' => 'function',
            'function' => array(
                'name' => 'wc_daily_sales_trend',
                'description' => 'Get daily orders and revenue for the last N days, with an overall trend direction (upward/downward/flat).',
                'parameters' => array(
                    'type' => 'object',
                    'properties' => array(
                        'days' => array('type' => 'integer', 'description' => 'Days to look back. Default: 14, max: 90.')
                    )
                )
            )
        )
    );
}

function monkbot_execute_woocommerce_tool($tool_name, $arguments)
{
    if (!class_exists('WooCommerce')) {
        return json_encode(array('error' => 'WooCommerce is not installed or active on this site.'));
    }

    switch ($tool_name) {
        case 'list_wc_products':
            $args = array(
                'limit' => absint($arguments['limit'] ?? 10),
                'offset' => absint($arguments['offset'] ?? 0),
                'return' => 'objects',
            );
            $products = wc_get_products($args);
            $products_data = array();

            foreach ($products as $product) {
                // Ensure $product is actually a WC_Product object
                if (is_a($product, 'WC_Product')) {
                    $products_data[] = array(
                        'id' => $product->get_id(),
                        'name' => $product->get_name(),
                        'type' => $product->get_type(),
                        'price' => $product->get_price(),
                        'regular_price' => $product->get_regular_price(),
                        'sale_price' => $product->get_sale_price(),
                        'status' => $product->get_status()
                    );
                }
            }
            return json_encode(array('products' => $products_data));

        case 'update_wc_product_price':
            $product_id = intval($arguments['product_id']);
            $product = wc_get_product($product_id);
            if (!$product) {
                return json_encode(array('error' => "Product ID $product_id not found."));
            }

            if (isset($arguments['regular_price']) && $arguments['regular_price'] !== '') {
                $product->set_regular_price($arguments['regular_price']);
            }
            if (isset($arguments['sale_price']) && $arguments['sale_price'] !== '') {
                if ($arguments['sale_price'] === 'clear') {
                    $product->set_sale_price('');
                } else {
                    $product->set_sale_price($arguments['sale_price']);
                }
            }
            $product->save();
            return json_encode(array('message' => "Successfully updated prices for product $product_id."));

        case 'list_wc_orders':
            $args = array(
                'limit' => absint($arguments['limit'] ?? 10),
            );
            if (!empty($arguments['status']) && $arguments['status'] !== 'any') {
                $args['status'] = $arguments['status'];
            }
            $orders = wc_get_orders($args);
            $orders_data = array();

            foreach ($orders as $order) {
                if (is_a($order, 'WC_Order')) {
                    $orders_data[] = array(
                        'id' => $order->get_id(),
                        'status' => $order->get_status(),
                        'total' => $order->get_total(),
                        'currency' => $order->get_currency(),
                        'date' => $order->get_date_created() ? $order->get_date_created()->date('Y-m-d H:i:s') : null,
                        'customer_id' => $order->get_customer_id()
                    );
                }
            }
            return json_encode(array('orders' => $orders_data));

        case 'update_wc_order_status':
            $order_id = intval($arguments['order_id']);
            $order = wc_get_order($order_id);
            if (!$order) {
                return json_encode(array('error' => "Order ID $order_id not found."));
            }

            $allowed_statuses = array('pending', 'processing', 'on-hold', 'completed', 'cancelled', 'refunded', 'failed');
            $status = in_array($arguments['status'], $allowed_statuses, true) ? $arguments['status'] : 'on-hold';
            $order->update_status($status, 'Status changed by MonkBot.');
            return json_encode(array('message' => "Successfully updated order $order_id to status $status."));

        // ── ANALYTICS ────────────────────────────────────────────────────────

        case 'wc_revenue_summary':
            $days = absint($arguments['days'] ?? 30);
            $days = min($days, 365);
            $from = gmdate('Y-m-d', strtotime("-{$days} days"));
            $to = gmdate('Y-m-d');

            $orders = wc_get_orders(array(
                'status' => array('wc-completed', 'wc-processing'),
                'date_created' => $from . '...' . $to,
                'limit' => -1,
                'return' => 'objects',
            ));

            $total_revenue = 0;
            $total_orders = count($orders);
            $currency = get_woocommerce_currency();

            foreach ($orders as $order) {
                $total_revenue += floatval($order->get_total());
            }

            return json_encode(array(
                'period_days' => $days,
                'from' => $from,
                'to' => $to,
                'total_orders' => $total_orders,
                'total_revenue' => round($total_revenue, 2),
                'currency' => $currency,
                'average_order' => $total_orders > 0 ? round($total_revenue / $total_orders, 2) : 0,
            ));

        case 'wc_top_products':
            $days = absint($arguments['days'] ?? 30);
            $limit = min(absint($arguments['limit'] ?? 10), 50);
            $from = gmdate('Y-m-d', strtotime("-{$days} days"));

            $orders = wc_get_orders(array(
                'status' => array('wc-completed', 'wc-processing'),
                'date_created' => $from . '...' . gmdate('Y-m-d'),
                'limit' => -1,
                'return' => 'objects',
            ));

            $product_sales = array();
            foreach ($orders as $order) {
                foreach ($order->get_items() as $item) {
                    $pid = $item->get_product_id();
                    if (!isset($product_sales[$pid])) {
                        $product_sales[$pid] = array(
                            'product_id' => $pid,
                            'name' => $item->get_name(),
                            'qty_sold' => 0,
                            'revenue' => 0,
                        );
                    }
                    $product_sales[$pid]['qty_sold'] += $item->get_quantity();
                    $product_sales[$pid]['revenue'] += floatval($item->get_total());
                }
            }

            $order_by = ($arguments['order_by'] ?? 'revenue') === 'qty_sold' ? 'qty_sold' : 'revenue';
            $order_dir = strtolower($arguments['order'] ?? 'desc') === 'asc' ? 'asc' : 'desc';

            usort($product_sales, function ($a, $b) use ($order_by, $order_dir) {
                $valA = $a[$order_by];
                $valB = $b[$order_by];
                if ($valA == $valB)
                    return 0;

                if ($order_dir === 'asc') {
                    return ($valA < $valB) ? -1 : 1;
                } else {
                    return ($valA > $valB) ? -1 : 1;
                }
            });

            $top = array_slice(array_values($product_sales), 0, $limit);
            foreach ($top as &$p) {
                $p['revenue'] = round($p['revenue'], 2);
            }

            return json_encode(array(
                'period_days' => $days,
                'top_products' => $top,
            ));

        case 'wc_category_breakdown':
            $days = absint($arguments['days'] ?? 30);
            $from = gmdate('Y-m-d', strtotime("-{$days} days"));

            $orders = wc_get_orders(array(
                'status' => array('wc-completed', 'wc-processing'),
                'date_created' => $from . '...' . gmdate('Y-m-d'),
                'limit' => -1,
                'return' => 'objects',
            ));

            $category_data = array();
            foreach ($orders as $order) {
                foreach ($order->get_items() as $item) {
                    $pid = $item->get_product_id();
                    $terms = get_the_terms($pid, 'product_cat');
                    $cats = $terms ? array_column(array_map(fn($t) => array('name' => $t->name), $terms), 'name') : array('Uncategorized');

                    foreach ($cats as $cat) {
                        if (!isset($category_data[$cat])) {
                            $category_data[$cat] = array('category' => $cat, 'qty_sold' => 0, 'revenue' => 0);
                        }
                        $category_data[$cat]['qty_sold'] += $item->get_quantity();
                        $category_data[$cat]['revenue'] += floatval($item->get_total());
                    }
                }
            }

            usort($category_data, fn($a, $b) => $b['revenue'] <=> $a['revenue']);
            foreach ($category_data as &$c) {
                $c['revenue'] = round($c['revenue'], 2);
            }

            return json_encode(array(
                'period_days' => $days,
                'category_breakdown' => array_values($category_data),
            ));

        case 'wc_revenue_by_region':
            $days = absint($arguments['days'] ?? 30);
            $from = gmdate('Y-m-d', strtotime("-{$days} days"));

            $orders = wc_get_orders(array(
                'status' => array('wc-completed', 'wc-processing'),
                'date_created' => $from . '...' . gmdate('Y-m-d'),
                'limit' => -1,
                'return' => 'objects',
            ));

            $regions = array();
            foreach ($orders as $order) {
                $country = $order->get_billing_country() ?: 'Unknown';
                $state = $order->get_billing_state() ?: '';
                $key = $country . ($state ? " / $state" : '');

                if (!isset($regions[$key])) {
                    $regions[$key] = array('region' => $key, 'country' => $country, 'orders' => 0, 'revenue' => 0);
                }
                $regions[$key]['orders']++;
                $regions[$key]['revenue'] += floatval($order->get_total());
            }

            usort($regions, fn($a, $b) => $b['revenue'] <=> $a['revenue']);
            foreach ($regions as &$r) {
                $r['revenue'] = round($r['revenue'], 2);
            }

            return json_encode(array(
                'period_days' => $days,
                'revenue_by_region' => array_values($regions),
            ));

        case 'wc_daily_sales_trend':
            $days = min(absint($arguments['days'] ?? 30), 90);
            $data = array();

            for ($i = $days - 1; $i >= 0; $i--) {
                $date = gmdate('Y-m-d', strtotime("-{$i} days"));
                $start = $date . ' 00:00:00';
                $end = $date . ' 23:59:59';

                $day_orders = wc_get_orders(array(
                    'status' => array('wc-completed', 'wc-processing'),
                    'date_created' => $date . '...' . $date,
                    'limit' => -1,
                    'return' => 'objects',
                ));

                $day_revenue = 0;
                foreach ($day_orders as $o) {
                    $day_revenue += floatval($o->get_total());
                }

                $data[] = array(
                    'date' => $date,
                    'orders' => count($day_orders),
                    'revenue' => round($day_revenue, 2),
                );
            }

            // Simple trend: compare first half to second half
            $half = intval(count($data) / 2);
            $first_rev = array_sum(array_column(array_slice($data, 0, $half), 'revenue'));
            $second_rev = array_sum(array_column(array_slice($data, $half), 'revenue'));
            $trend = $second_rev > $first_rev ? 'upward' : ($second_rev < $first_rev ? 'downward' : 'flat');

            return json_encode(array(
                'period_days' => $days,
                'trend' => $trend,
                'daily_data' => $data,
            ));
    }
    return false;
}


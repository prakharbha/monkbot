<?php
/**
 * MonkBot Tool Module: Database Tools
 * Read-only database schema inspection and safe parameterized SELECT queries.
 *
 * All queries follow WordPress DB guidelines:
 * - Free-form SELECTs use $wpdb->prepare() with a template + params pattern
 * - Table identifier in DESCRIBE uses the %i placeholder (WP 6.2+)
 * - Schema results are cached with wp_cache_set() for 60 seconds
 * - Sensitive option names are blocked from get_option
 */

if (!defined('ABSPATH')) {
    exit;
}

function monkbot_execute_database_tool($tool_name, $arguments)
{
    global $wpdb;

    switch ($tool_name) {

        // ── SCHEMA ──────────────────────────────────────────────────────────

        case 'database_schema':
            $cache_key = 'monkbot_db_schema';
            $cache_group = 'monkbot';
            $cached = wp_cache_get($cache_key, $cache_group);
            if (false !== $cached) {
                return $cached;
            }

            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $tables = $wpdb->get_results('SHOW TABLES', ARRAY_N);
            $schema_data = array();

            foreach ($tables as $table_row) {
                $table_name = $table_row[0];
                // Inline prepare() so PHPCS can statically verify the query is safe
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
                $columns = $wpdb->get_results(
                    $wpdb->prepare('DESCRIBE %i', $table_name), // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- %i is a valid identifier placeholder (WP 6.2+)
                    ARRAY_A
                );
                $schema_data[$table_name] = $columns;
            }

            $result = json_encode(array(
                'table_count' => count($schema_data),
                'tables' => $schema_data,
            ));
            wp_cache_set($cache_key, $result, $cache_group, 60);
            return $result;

        // ── PARAMETERIZED SELECT ─────────────────────────────────────────────

        case 'database_query':
            /*
             * Accepts:
             *   sql    — A SQL SELECT template using %s, %d, or %f placeholders.
             *            Example: "SELECT * FROM %i WHERE post_status = %s"
             *   params — Ordered array of values to bind into the placeholders.
             *            Example: ["wp_posts", "publish"]
             *   limit  — Max rows (default 50, max 500)
             *
             * $wpdb->prepare() is called with the template + params so no raw
             * user data ever reaches the database engine unescaped.
             */
            $sql_template = trim($arguments['sql'] ?? '');
            $params = $arguments['params'] ?? array();

            if (empty($sql_template)) {
                return json_encode(array('error' => 'sql is required.'));
            }

            // 1. Only SELECT statements
            $first_word = strtoupper(strtok($sql_template, " \t\n\r"));
            if ($first_word !== 'SELECT') {
                return json_encode(array(
                    'error' => 'Only SELECT queries are allowed. Use specific MonkBot tools for write operations.',
                ));
            }

            // 2. Block dangerous SQL patterns in the template
            $blocklist = array(
                '/\bUNION\b/i',
                '/\bINTO\s+OUTFILE\b/i',
                '/\bLOAD_FILE\b/i',
                '/\bSLEEP\s*\(/i',
                '/\bBENCHMARK\s*\(/i',
                '/\bINFORMATION_SCHEMA\b/i',
            );
            foreach ($blocklist as $pattern) {
                if (preg_match($pattern, $sql_template)) {
                    return json_encode(array('error' => 'Query contains a disallowed SQL pattern.'));
                }
            }

            // 3. Enforce row limit (append only if not already in template)
            $limit = min(absint($arguments['limit'] ?? 50), 500);
            if (!preg_match('/\bLIMIT\b/i', $sql_template)) {
                $sql_template .= ' LIMIT %d';
                $params[] = $limit;
            }

            // 4. Build the prepared query — all user values go through prepare()
            if (!empty($params)) {
                $prepared_sql = $wpdb->prepare($sql_template, ...$params); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- template is validate-only-SELECT above
            } else {
                // No params: template has no placeholders, still SELECT-only and blocklist-cleared
                $prepared_sql = $wpdb->prepare($sql_template); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
            }

            // 5. Execute with error suppression so internals are never exposed
            $wpdb->suppress_errors(true);
            // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
            $results = $wpdb->get_results($prepared_sql, ARRAY_A);
            $last_error = $wpdb->last_error;
            $wpdb->suppress_errors(false);

            if ($last_error) {
                return json_encode(array('error' => 'Query failed. Please check your SQL syntax and placeholders.'));
            }

            return json_encode(array(
                'row_count' => count($results),
                'results' => $results,
            ));

        // ── OPTIONS ─────────────────────────────────────────────────────────

        case 'get_option':
            $option_name = sanitize_key($arguments['option_name'] ?? '');
            if (empty($option_name)) {
                return json_encode(array('error' => 'option_name is required.'));
            }

            // Block sensitive options that must never be exposed via AI
            $blocked_options = array(
                'auth_key',
                'secure_auth_key',
                'logged_in_key',
                'nonce_key',
                'auth_salt',
                'secure_auth_salt',
                'logged_in_salt',
                'nonce_salt',
                'monkbot_api_key',
                'monkbot_api_base_url',
                'monkbot_telegram_bot_token',
                'monkbot_telegram_secret_token',
            );

            if (in_array($option_name, $blocked_options, true)) {
                return json_encode(array('error' => "Option '$option_name' is blocked for security reasons."));
            }

            $value = get_option($option_name, '__NOT_FOUND__');
            if ($value === '__NOT_FOUND__') {
                return json_encode(array('found' => false, 'option' => $option_name));
            }
            return json_encode(array('found' => true, 'option' => $option_name, 'value' => $value));
    }

    return false;
}

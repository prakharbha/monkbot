<?php
/**
 * SaaS integration helpers.
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Returns the hardcoded MonkBot SaaS API base URL.
 */
function monkbot_get_api_base_url()
{
    // Hardcoded to ensure all plugins connect to the production SaaS backend.
    return 'https://monkbot.app/api';
}

/**
 * Returns the configured MonkBot SaaS API key.
 */
function monkbot_get_api_key()
{
    return trim((string) get_option('monkbot_api_key', ''));
}

/**
 * Returns the current site domain.
 */
function monkbot_get_site_domain()
{
    $host = wp_parse_url(home_url(), PHP_URL_HOST);
    $port = wp_parse_url(home_url(), PHP_URL_PORT);
    $domain = strtolower((string) $host);
    if (!empty($port) && !in_array($port, array(80, 443))) {
        $domain .= ':' . $port;
    }
    return $domain;
}


/**
 * Shared POST request helper to MonkBot SaaS API.
 */
function monkbot_saas_post($path, $payload, $timeout = 60)
{
    $api_key = monkbot_get_api_key();
    if ($api_key === '') {
        return array(
            'ok' => false,
            'status' => 401,
            'error' => __('MonkBot API key is missing. Please add it in MonkBot Settings.', 'monkbot'),
            'data' => null,
        );
    }

    $url = monkbot_get_api_base_url() . $path;
    $response = wp_remote_post($url, array(
        'headers' => array(
            'Authorization' => 'Bearer ' . $api_key,
            'Content-Type' => 'application/json',
            'X-Monkbot-Domain' => monkbot_get_site_domain(),
            'X-Monkbot-Site-Url' => home_url(),
            'X-Monkbot-Plugin-Version' => MONKBOT_VERSION,
        ),
        'body' => wp_json_encode($payload),
        'timeout' => $timeout,
    ));

    if (is_wp_error($response)) {
        return array(
            'ok' => false,
            'status' => 502,
            'error' => $response->get_error_message(),
            'data' => null,
        );
    }

    $status = (int) wp_remote_retrieve_response_code($response);
    $body = wp_remote_retrieve_body($response);
    $decoded = json_decode($body, true);

    if (!is_array($decoded)) {
        $decoded = array();
    }

    if ($status < 200 || $status >= 300) {
        return array(
            'ok' => false,
            'status' => $status,
            'error' => (string) ($decoded['message'] ?? $decoded['error'] ?? __('SaaS API request failed.', 'monkbot')),
            'data' => $decoded,
        );
    }

    return array(
        'ok' => true,
        'status' => $status,
        'error' => '',
        'data' => $decoded,
    );
}

/**
 * Validates the local site against MonkBot SaaS.
 * Uses a short transient cache to avoid excessive validation calls.
 */
function monkbot_validate_saas_access($force_refresh = false)
{
    $cache_key = 'monkbot_saas_validation';

    if (!$force_refresh) {
        $cached = get_transient($cache_key);
        if (is_array($cached) && isset($cached['allowed'])) {
            return $cached;
        }
    }

    $result = monkbot_saas_post('/v1/plugin/validate', array(
        'domain' => monkbot_get_site_domain(),
        'site_url' => home_url(),
    ), 20);

    if (!$result['ok']) {
        $response = array(
            'allowed' => false,
            'message' => $result['error'] ?: __('Unable to validate MonkBot API key.', 'monkbot'),
        );
        set_transient($cache_key, $response, 2 * MINUTE_IN_SECONDS);
        return $response;
    }

    $data = $result['data'];
    $allowed = !empty($data['allowed']);
    $response = array(
        'allowed' => $allowed,
        'message' => (string) ($data['message'] ?? ''),
        'plan' => (string) ($data['plan'] ?? ''),
        'credits_remaining' => isset($data['credits_remaining']) ? $data['credits_remaining'] : null,
    );

    set_transient($cache_key, $response, 5 * MINUTE_IN_SECONDS);
    return $response;
}

/**
 * Proxies OpenAI-compatible chat completions via MonkBot SaaS.
 */
function monkbot_saas_chat_completion($payload, $timeout = 120)
{
    return monkbot_saas_post('/v1/plugin/chat-completions', $payload, $timeout);
}

/**
 * Show admin warning when SaaS key/domain validation fails.
 */
function monkbot_saas_admin_notice()
{
    if (!current_user_can('manage_options')) {
        return;
    }

    $screen = function_exists('get_current_screen') ? get_current_screen() : null;
    if (!$screen || strpos((string) $screen->id, 'monkbot') === false) {
        return;
    }

    $validation = monkbot_validate_saas_access(false);
    if (!empty($validation['allowed'])) {
        return;
    }

    $message = !empty($validation['message'])
        ? $validation['message']
        : __('MonkBot is disabled until a valid API key is configured for this domain.', 'monkbot');

    echo '<div class="notice notice-error"><p><strong>MonkBot SaaS:</strong> ' . esc_html($message) . '</p></div>';
}
add_action('admin_notices', 'monkbot_saas_admin_notice');

/**
 * Refresh validation cache whenever settings are saved.
 */
function monkbot_clear_saas_validation_cache()
{
    delete_transient('monkbot_saas_validation');
}
add_action('update_option_monkbot_api_key', 'monkbot_clear_saas_validation_cache');

# MonkBot SaaS API Contract (Plugin Integration)

The plugin now calls your SaaS backend instead of OpenAI directly.

## Auth

- Header: `Authorization: Bearer <monkbot_api_key>`
- Header: `X-Monkbot-Domain: <site-domain>`
- Header: `X-Monkbot-Site-Url: <wp-home-url>`
- Header: `X-Monkbot-Plugin-Version: <plugin-version>`

## 1) Validate Site

- `POST /v1/plugin/validate`
- Request JSON:

```json
{
  "domain": "example.com",
  "site_url": "https://example.com"
}
```

- Success JSON:

```json
{
  "allowed": true,
  "message": "OK",
  "plan": "free",
  "credits_remaining": 123
}
```

- Denied JSON (HTTP 402/403/429):

```json
{
  "allowed": false,
  "message": "Domain not linked or credits exhausted."
}
```

## 2) Chat Completions Proxy

- `POST /v1/plugin/chat-completions`
- Request JSON: OpenAI-compatible payload from plugin:

```json
{
  "model": "gpt-4o-mini",
  "messages": [],
  "tools": [],
  "tool_choice": "auto"
}
```

- Success JSON: OpenAI-compatible response shape:

```json
{
  "choices": [
    {
      "message": {
        "role": "assistant",
        "content": "..."
      }
    }
  ]
}
```

- Error JSON:

```json
{
  "message": "Insufficient credits"
}
```

Use non-2xx for failures (e.g. 401, 402, 403, 429, 500).
